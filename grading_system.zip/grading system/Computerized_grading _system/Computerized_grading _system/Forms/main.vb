﻿Public Class main
    Private Sub btnadmission_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadmission.Click
        Register.Show()
    End Sub
    Private Sub btnstudent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstudent.Click
        View_Student.Show()
    End Sub
    Private Sub btncompute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncompute.Click
        Computegrade.Show()
    End Sub
    Private Sub btnstudentrecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstudentrecord.Click
        StudentRecord.Show()
    End Sub
    Private Sub btncourse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncourse.Click
        loginResult.Show()
    End Sub
End Class