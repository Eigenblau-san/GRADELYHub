﻿Imports System.Data.OleDb

Public Class Studentresult
    Private Sub Studentresult_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Left = (Screen.PrimaryScreen.WorkingArea.Width - Me.Width) / 2
        Me.Top = (Screen.PrimaryScreen.WorkingArea.Height - Me.Height) / 2
        getgraderecord()
    End Sub
    Private Sub studpic()
        Try
            ConnDB()
            Dim arrImage() As Byte
            Dim myMS As New IO.MemoryStream
            Dim da As New OleDbDataAdapter(("select * from register where admnumber='" & Trim(loginResult.txtadmnumber.Text) & "'"), conn)

            Dim dt As New DataTable
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                If Not IsDBNull(dt.Rows(0).Item("photo")) Then
                    arrImage = dt.Rows(0).Item("photo")
                    For Each ar As Byte In arrImage
                        myMS.WriteByte(ar)
                    Next
                    Me.PictureBox1.Image = System.Drawing.Image.FromStream(myMS)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub getgraderecord()
        Try
            ConnDB()
            Dim da As New OleDbDataAdapter(("select * from grade where admnumber='" & Trim(loginResult.txtadmnumber.Text) & "'"), conn)
            Dim dt As New DataTable
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                Me.ibladmnumber.Text = dt.Rows(0).Item("admnumber") & ""
                Me.iblstudentname.Text = dt.Rows(0).Item("studname") & ""
                Me.iblsession.Text = dt.Rows(0).Item("session1") & ""
                Me.iblterm.Text = dt.Rows(0).Item("term") & ""
                Me.iblclass.Text = dt.Rows(0).Item("class") & ""
                Me.iblsubject1.Text = dt.Rows(0).Item("subject1") & ""
                Me.iblsubject2.Text = dt.Rows(0).Item("subject2") & ""
                Me.iblsubject3.Text = dt.Rows(0).Item("subject3") & ""
                Me.iblsubject4.Text = dt.Rows(0).Item("subject4") & ""
                Me.iblsubject5.Text = dt.Rows(0).Item("subject5") & ""
                Me.iblsubject6.Text = dt.Rows(0).Item("subject6") & ""
                Me.iblsubject7.Text = dt.Rows(0).Item("subject7") & ""
                Me.iblscore1.Text = dt.Rows(0).Item("score1") & ""
                Me.iblscore2.Text = dt.Rows(0).Item("score2") & ""
                Me.iblscore3.Text = dt.Rows(0).Item("score3") & ""
                Me.iblscore4.Text = dt.Rows(0).Item("score4") & ""
                Me.iblscore5.Text = dt.Rows(0).Item("score5") & ""
                Me.iblscore6.Text = dt.Rows(0).Item("score6") & ""
                Me.iblscore7.Text = dt.Rows(0).Item("score7") & ""
                Me.iblgrade1.Text = dt.Rows(0).Item("grade1") & ""
                Me.iblgrade2.Text = dt.Rows(0).Item("grade2") & ""
                Me.iblgrade3.Text = dt.Rows(0).Item("grade3") & ""
                Me.iblgrade4.Text = dt.Rows(0).Item("grade4") & ""
                Me.iblgrade5.Text = dt.Rows(0).Item("grade5") & ""
                Me.iblgrade6.Text = dt.Rows(0).Item("grade6") & ""
                Me.iblgrade7.Text = dt.Rows(0).Item("grade7") & ""
                Me.ibltotalscore.Text = dt.Rows(0).Item("total") & ""
                Me.iblaverage.Text = dt.Rows(0).Item("remark") & ""
                Me.iblremark.Text = dt.Rows(0).Item("average") & ""
            End If
            studpic()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click
        btncancel.Visible = False
        btnprint.Visible = False
        PrintForm1.Print()
    End Sub
End Class