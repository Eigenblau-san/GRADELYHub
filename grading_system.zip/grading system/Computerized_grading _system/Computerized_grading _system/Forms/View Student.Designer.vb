﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class View_Student
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(View_Student))
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtclass = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtlga = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtaddress = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtstudname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Txtparentemail = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtparentphone = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtparentoccupation = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtparentname = New System.Windows.Forms.TextBox()
        Me.txtadmissionnumber = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cmddayborder = New System.Windows.Forms.TextBox()
        Me.cmdstate = New System.Windows.Forms.TextBox()
        Me.txtdatebirth = New System.Windows.Forms.TextBox()
        Me.cmdsex = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Btnrefresh = New System.Windows.Forms.Button()
        Me.Btndelete = New System.Windows.Forms.Button()
        Me.btnedit = New System.Windows.Forms.Button()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.btnview = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(16, 136)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(102, 13)
        Me.Label13.TabIndex = 218
        Me.Label13.Text = "DATE OF BIRTH"
        '
        'txtclass
        '
        Me.txtclass.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtclass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclass.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclass.Location = New System.Drawing.Point(177, 235)
        Me.txtclass.Multiline = True
        Me.txtclass.Name = "txtclass"
        Me.txtclass.ReadOnly = True
        Me.txtclass.Size = New System.Drawing.Size(139, 30)
        Me.txtclass.TabIndex = 211
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(13, 243)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(92, 13)
        Me.Label11.TabIndex = 217
        Me.Label11.Text = "ADMITTED TO"
        '
        'txtlga
        '
        Me.txtlga.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtlga.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtlga.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlga.Location = New System.Drawing.Point(177, 279)
        Me.txtlga.Multiline = True
        Me.txtlga.Name = "txtlga"
        Me.txtlga.Size = New System.Drawing.Size(236, 32)
        Me.txtlga.TabIndex = 212
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(14, 285)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 216
        Me.Label7.Text = "LGA"
        '
        'txtaddress
        '
        Me.txtaddress.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtaddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtaddress.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaddress.Location = New System.Drawing.Point(178, 170)
        Me.txtaddress.Multiline = True
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(240, 54)
        Me.txtaddress.TabIndex = 210
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(14, 175)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 13)
        Me.Label4.TabIndex = 215
        Me.Label4.Text = "ADDRESS"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(17, 101)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 214
        Me.Label2.Text = "SEX"
        '
        'txtstudname
        '
        Me.txtstudname.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtstudname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtstudname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstudname.Location = New System.Drawing.Point(177, 51)
        Me.txtstudname.Multiline = True
        Me.txtstudname.Name = "txtstudname"
        Me.txtstudname.Size = New System.Drawing.Size(238, 30)
        Me.txtstudname.TabIndex = 207
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(17, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 13)
        Me.Label1.TabIndex = 213
        Me.Label1.Text = "STUDENT NAME"
        '
        'Txtparentemail
        '
        Me.Txtparentemail.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Txtparentemail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtparentemail.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtparentemail.Location = New System.Drawing.Point(177, 469)
        Me.Txtparentemail.Multiline = True
        Me.Txtparentemail.Name = "Txtparentemail"
        Me.Txtparentemail.Size = New System.Drawing.Size(295, 30)
        Me.Txtparentemail.TabIndex = 223
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(17, 469)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 13)
        Me.Label5.TabIndex = 232
        Me.Label5.Text = "PARENT EMAIL"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(17, 362)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(96, 13)
        Me.Label17.TabIndex = 231
        Me.Label17.Text = "PARENT NAME"
        '
        'txtparentphone
        '
        Me.txtparentphone.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtparentphone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtparentphone.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtparentphone.Location = New System.Drawing.Point(177, 430)
        Me.txtparentphone.Multiline = True
        Me.txtparentphone.Name = "txtparentphone"
        Me.txtparentphone.Size = New System.Drawing.Size(238, 30)
        Me.txtparentphone.TabIndex = 222
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(17, 430)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 13)
        Me.Label3.TabIndex = 230
        Me.Label3.Text = "PARENT PHONE"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(17, 512)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(157, 13)
        Me.Label10.TabIndex = 228
        Me.Label10.Text = "DAY STUDENT/ BORDER"
        '
        'txtparentoccupation
        '
        Me.txtparentoccupation.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtparentoccupation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtparentoccupation.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtparentoccupation.Location = New System.Drawing.Point(177, 394)
        Me.txtparentoccupation.Multiline = True
        Me.txtparentoccupation.Name = "txtparentoccupation"
        Me.txtparentoccupation.Size = New System.Drawing.Size(236, 30)
        Me.txtparentoccupation.TabIndex = 221
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(17, 394)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(141, 13)
        Me.Label12.TabIndex = 227
        Me.Label12.Text = "PARENT OCCUPATION"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(17, 322)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(47, 13)
        Me.Label6.TabIndex = 226
        Me.Label6.Text = "STATE"
        '
        'txtparentname
        '
        Me.txtparentname.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtparentname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtparentname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtparentname.Location = New System.Drawing.Point(177, 357)
        Me.txtparentname.Multiline = True
        Me.txtparentname.Name = "txtparentname"
        Me.txtparentname.Size = New System.Drawing.Size(236, 30)
        Me.txtparentname.TabIndex = 220
        '
        'txtadmissionnumber
        '
        Me.txtadmissionnumber.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtadmissionnumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtadmissionnumber.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadmissionnumber.Location = New System.Drawing.Point(177, 12)
        Me.txtadmissionnumber.Multiline = True
        Me.txtadmissionnumber.Name = "txtadmissionnumber"
        Me.txtadmissionnumber.Size = New System.Drawing.Size(238, 30)
        Me.txtadmissionnumber.TabIndex = 0
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(16, 22)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(125, 13)
        Me.Label9.TabIndex = 234
        Me.Label9.Text = "ADMISION NUMBER"
        '
        'cmddayborder
        '
        Me.cmddayborder.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmddayborder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.cmddayborder.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmddayborder.Location = New System.Drawing.Point(177, 507)
        Me.cmddayborder.Multiline = True
        Me.cmddayborder.Name = "cmddayborder"
        Me.cmddayborder.Size = New System.Drawing.Size(238, 30)
        Me.cmddayborder.TabIndex = 235
        '
        'cmdstate
        '
        Me.cmdstate.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdstate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.cmdstate.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdstate.Location = New System.Drawing.Point(177, 319)
        Me.cmdstate.Multiline = True
        Me.cmdstate.Name = "cmdstate"
        Me.cmdstate.Size = New System.Drawing.Size(238, 30)
        Me.cmdstate.TabIndex = 236
        '
        'txtdatebirth
        '
        Me.txtdatebirth.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtdatebirth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdatebirth.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdatebirth.Location = New System.Drawing.Point(177, 126)
        Me.txtdatebirth.Multiline = True
        Me.txtdatebirth.Name = "txtdatebirth"
        Me.txtdatebirth.Size = New System.Drawing.Size(238, 30)
        Me.txtdatebirth.TabIndex = 237
        '
        'cmdsex
        '
        Me.cmdsex.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.cmdsex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.cmdsex.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdsex.Location = New System.Drawing.Point(178, 90)
        Me.cmdsex.Multiline = True
        Me.cmdsex.Name = "cmdsex"
        Me.cmdsex.Size = New System.Drawing.Size(238, 30)
        Me.cmdsex.TabIndex = 238
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Image = Global.Computerized_grading__system.My.Resources.Resources.users3
        Me.PictureBox1.Location = New System.Drawing.Point(434, 13)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(120, 143)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 239
        Me.PictureBox1.TabStop = False
        '
        'Btnrefresh
        '
        Me.Btnrefresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btnrefresh.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnrefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btnrefresh.Location = New System.Drawing.Point(298, 558)
        Me.Btnrefresh.Name = "Btnrefresh"
        Me.Btnrefresh.Size = New System.Drawing.Size(60, 28)
        Me.Btnrefresh.TabIndex = 244
        Me.Btnrefresh.Text = "Refresh"
        Me.Btnrefresh.UseVisualStyleBackColor = True
        '
        'Btndelete
        '
        Me.Btndelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btndelete.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btndelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btndelete.Location = New System.Drawing.Point(232, 558)
        Me.Btndelete.Name = "Btndelete"
        Me.Btndelete.Size = New System.Drawing.Size(60, 28)
        Me.Btndelete.TabIndex = 243
        Me.Btndelete.Text = "Delete"
        Me.Btndelete.UseVisualStyleBackColor = True
        '
        'btnedit
        '
        Me.btnedit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnedit.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnedit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnedit.Location = New System.Drawing.Point(165, 558)
        Me.btnedit.Name = "btnedit"
        Me.btnedit.Size = New System.Drawing.Size(60, 28)
        Me.btnedit.TabIndex = 242
        Me.btnedit.Text = "Edit"
        Me.btnedit.UseVisualStyleBackColor = True
        '
        'btncancel
        '
        Me.btncancel.BackColor = System.Drawing.Color.White
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btncancel.Location = New System.Drawing.Point(364, 558)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(82, 28)
        Me.btncancel.TabIndex = 241
        Me.btncancel.Text = "   &Cancel"
        Me.btncancel.UseVisualStyleBackColor = False
        '
        'btnview
        '
        Me.btnview.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnview.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnview.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnview.Location = New System.Drawing.Point(99, 559)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(60, 28)
        Me.btnview.TabIndex = 240
        Me.btnview.Text = "View"
        Me.btnview.UseVisualStyleBackColor = True
        '
        'View_Student
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOrange
        Me.ClientSize = New System.Drawing.Size(570, 603)
        Me.Controls.Add(Me.Btnrefresh)
        Me.Controls.Add(Me.Btndelete)
        Me.Controls.Add(Me.btnedit)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnview)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.cmdsex)
        Me.Controls.Add(Me.txtdatebirth)
        Me.Controls.Add(Me.cmdstate)
        Me.Controls.Add(Me.cmddayborder)
        Me.Controls.Add(Me.txtadmissionnumber)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Txtparentemail)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtparentphone)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtparentoccupation)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtparentname)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtclass)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtlga)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtaddress)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtstudname)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "View_Student"
        Me.Text = "View Student"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtclass As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtlga As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtaddress As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtstudname As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Txtparentemail As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtparentphone As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtparentoccupation As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtparentname As System.Windows.Forms.TextBox
    Friend WithEvents txtadmissionnumber As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cmddayborder As System.Windows.Forms.TextBox
    Friend WithEvents cmdstate As System.Windows.Forms.TextBox
    Friend WithEvents txtdatebirth As System.Windows.Forms.TextBox
    Friend WithEvents cmdsex As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Btnrefresh As System.Windows.Forms.Button
    Friend WithEvents Btndelete As System.Windows.Forms.Button
    Friend WithEvents btnedit As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnview As System.Windows.Forms.Button
End Class
