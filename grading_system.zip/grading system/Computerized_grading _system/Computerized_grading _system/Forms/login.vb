﻿Imports System.Data.OleDb

Public Class login

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(+1)
        If ProgressBar1.Value = 10 Then
            iblStatus.Text = "Gathering required data."
        ElseIf ProgressBar1.Value = 25 Then
            iblStatus.Text = "Gathering required data....."
        ElseIf ProgressBar1.Value = 40 Then
            iblStatus.Text = "Please wait."
        ElseIf ProgressBar1.Value = 65 Then
            iblStatus.Text = "Please wait...."
        ElseIf ProgressBar1.Value = 75 Then
            iblStatus.Text = "Verifying Data...."
        ElseIf ProgressBar1.Value = 82 Then
            iblStatus.Text = "Login Successful."
        ElseIf ProgressBar1.Value = 90 Then
            picloading.Visible = False
            Timer1.Stop()
            login()
        End If
    End Sub
    Private Sub login()
        Try
            If txtUsername.Text = "" And txtPassword.Text = "" Then
                MsgBox("Please enter username and password")
                txtUsername.Focus()
            ElseIf txtUsername.Text = "" Then
                MsgBox("Please enter username")
                txtUsername.Focus()
            ElseIf txtPassword.Text = "" Then
                MsgBox("Please enter password")
                txtPassword.Focus()
            Else
                Sql = "SELECT * FROM login WHERE username = '" & txtUsername.Text & "' AND password ='" & txtPassword.Text & "'"
                ConnDB()
                cmd = New OleDbCommand(Sql, conn)
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)

                If dr.Read = True Then
                    iblStatus.Text = "Login Successfull"
                    main.Show()

                    main.ibluser.Text = txtUsername.Text
                    main.iblrole.Text = txtPassword.Text

                    MsgBox("Welcome " & " " & txtUsername.Text, MsgBoxStyle.Information, "Login Report")
                    Me.Close()
                Else
                    MsgBox("Incorrect Username or Password", MsgBoxStyle.Exclamation, "Login")
                    iblStatus.Text = "Incorrect Username or Password"
                End If
                conn.Close()
            End If
        Catch ex As Exception
            MsgBox("" & ex.Message)
        End Try
    End Sub
    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        Timer1.Enabled = True
        ProgressBar1.Enabled = True
        ProgressBar1.Value = 0
        picloading.Visible = True
        iblStatus.Visible = True
    End Sub
    Private Sub login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtPassword.PasswordChar = "*"
        Me.Left = (Screen.PrimaryScreen.WorkingArea.Width - Me.Width) / 2
        Me.Top = (Screen.PrimaryScreen.WorkingArea.Height - Me.Height) / 2
        ProgressBar1.Enabled = False
    End Sub
End Class