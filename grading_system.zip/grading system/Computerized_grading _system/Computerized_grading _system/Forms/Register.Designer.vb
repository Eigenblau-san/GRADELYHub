﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Register
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Register))
        Me.Label17 = New System.Windows.Forms.Label()
        Me.cmdsex = New System.Windows.Forms.ComboBox()
        Me.txtadmissionnumber = New System.Windows.Forms.TextBox()
        Me.upload = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtparentoccupation = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtlga = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtparentname = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtstudname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdstate = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtaddress = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtclass = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtdatebirth = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtparentphone = New System.Windows.Forms.TextBox()
        Me.Txtparentemail = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cmddayborder = New System.Windows.Forms.ComboBox()
        Me.dgw = New System.Windows.Forms.DataGridView()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomerID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ibltotal = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Btnrefresh = New System.Windows.Forms.Button()
        Me.btnregister = New System.Windows.Forms.Button()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label14 = New System.Windows.Forms.Label()
        CType(Me.dgw, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(415, 55)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(96, 13)
        Me.Label17.TabIndex = 209
        Me.Label17.Text = "PARENT NAME"
        '
        'cmdsex
        '
        Me.cmdsex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmdsex.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdsex.FormattingEnabled = True
        Me.cmdsex.Items.AddRange(New Object() {"Male", "Female"})
        Me.cmdsex.Location = New System.Drawing.Point(169, 48)
        Me.cmdsex.Name = "cmdsex"
        Me.cmdsex.Size = New System.Drawing.Size(138, 25)
        Me.cmdsex.TabIndex = 2
        '
        'txtadmissionnumber
        '
        Me.txtadmissionnumber.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtadmissionnumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtadmissionnumber.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadmissionnumber.ForeColor = System.Drawing.Color.DarkRed
        Me.txtadmissionnumber.Location = New System.Drawing.Point(571, 232)
        Me.txtadmissionnumber.Multiline = True
        Me.txtadmissionnumber.Name = "txtadmissionnumber"
        Me.txtadmissionnumber.ReadOnly = True
        Me.txtadmissionnumber.Size = New System.Drawing.Size(238, 30)
        Me.txtadmissionnumber.TabIndex = 13
        '
        'upload
        '
        Me.upload.BackColor = System.Drawing.Color.GreenYellow
        Me.upload.Cursor = System.Windows.Forms.Cursors.Hand
        Me.upload.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.upload.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.upload.Location = New System.Drawing.Point(885, 164)
        Me.upload.Name = "upload"
        Me.upload.Size = New System.Drawing.Size(122, 38)
        Me.upload.TabIndex = 193
        Me.upload.Text = "Upload image"
        Me.upload.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(417, 242)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(125, 13)
        Me.Label9.TabIndex = 204
        Me.Label9.Text = "ADMISION NUMBER"
        '
        'txtparentoccupation
        '
        Me.txtparentoccupation.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtparentoccupation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtparentoccupation.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtparentoccupation.Location = New System.Drawing.Point(571, 81)
        Me.txtparentoccupation.Multiline = True
        Me.txtparentoccupation.Name = "txtparentoccupation"
        Me.txtparentoccupation.Size = New System.Drawing.Size(236, 30)
        Me.txtparentoccupation.TabIndex = 9
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(415, 87)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(141, 13)
        Me.Label12.TabIndex = 201
        Me.Label12.Text = "PARENT OCCUPATION"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(415, 19)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(47, 13)
        Me.Label6.TabIndex = 200
        Me.Label6.Text = "STATE"
        '
        'txtlga
        '
        Me.txtlga.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtlga.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtlga.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlga.Location = New System.Drawing.Point(169, 232)
        Me.txtlga.Multiline = True
        Me.txtlga.Name = "txtlga"
        Me.txtlga.Size = New System.Drawing.Size(236, 32)
        Me.txtlga.TabIndex = 6
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 238)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 199
        Me.Label7.Text = "LGA"
        '
        'txtparentname
        '
        Me.txtparentname.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtparentname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtparentname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtparentname.Location = New System.Drawing.Point(571, 44)
        Me.txtparentname.Multiline = True
        Me.txtparentname.Name = "txtparentname"
        Me.txtparentname.Size = New System.Drawing.Size(236, 30)
        Me.txtparentname.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(9, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 197
        Me.Label2.Text = "SEX"
        '
        'txtstudname
        '
        Me.txtstudname.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtstudname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtstudname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstudname.Location = New System.Drawing.Point(169, 12)
        Me.txtstudname.Multiline = True
        Me.txtstudname.Name = "txtstudname"
        Me.txtstudname.Size = New System.Drawing.Size(238, 30)
        Me.txtstudname.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 13)
        Me.Label1.TabIndex = 196
        Me.Label1.Text = "STUDENT NAME"
        '
        'cmdstate
        '
        Me.cmdstate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmdstate.FormattingEnabled = True
        Me.cmdstate.Items.AddRange(New Object() {"Abia ", "Abuja", "Adamawa", "Akwa Ibom ", "Anambra ", "Bauchi ", "Bayelsa ", "Benue ", "Borno ", "Cross River ", "Delta ", "Ebonyi", "Edo ", "Ekiti", "Enugu ", "Gombe ", "Imo ", "Jigawa ", "Kaduna ", "Kano ", "Katsina ", "Kebbi ", "Kogi", "Kwara ", "Lagos ", "Nasarawa ", "Niger ", "Ogun", "Ondo", "Osun ", "Oyo ", "Plateau ", "Rivers ", "Sokoto ", "Taraba ", "Yobe ", "Zamfara "})
        Me.cmdstate.Location = New System.Drawing.Point(571, 13)
        Me.cmdstate.Name = "cmdstate"
        Me.cmdstate.Size = New System.Drawing.Size(169, 21)
        Me.cmdstate.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 128)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 13)
        Me.Label4.TabIndex = 198
        Me.Label4.Text = "ADDRESS"
        '
        'txtaddress
        '
        Me.txtaddress.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtaddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtaddress.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaddress.Location = New System.Drawing.Point(170, 123)
        Me.txtaddress.Multiline = True
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(240, 54)
        Me.txtaddress.TabIndex = 4
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(5, 196)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(92, 13)
        Me.Label11.TabIndex = 202
        Me.Label11.Text = "ADMITTED TO"
        '
        'txtclass
        '
        Me.txtclass.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtclass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclass.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclass.Location = New System.Drawing.Point(169, 188)
        Me.txtclass.Multiline = True
        Me.txtclass.Name = "txtclass"
        Me.txtclass.Size = New System.Drawing.Size(139, 30)
        Me.txtclass.TabIndex = 5
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(8, 89)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(102, 13)
        Me.Label13.TabIndex = 206
        Me.Label13.Text = "DATE OF BIRTH"
        '
        'txtdatebirth
        '
        Me.txtdatebirth.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdatebirth.Location = New System.Drawing.Point(170, 81)
        Me.txtdatebirth.Name = "txtdatebirth"
        Me.txtdatebirth.Size = New System.Drawing.Size(170, 25)
        Me.txtdatebirth.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(415, 123)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 13)
        Me.Label3.TabIndex = 208
        Me.Label3.Text = "PARENT PHONE"
        '
        'txtparentphone
        '
        Me.txtparentphone.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtparentphone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtparentphone.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtparentphone.Location = New System.Drawing.Point(571, 117)
        Me.txtparentphone.Multiline = True
        Me.txtparentphone.Name = "txtparentphone"
        Me.txtparentphone.Size = New System.Drawing.Size(238, 30)
        Me.txtparentphone.TabIndex = 10
        '
        'Txtparentemail
        '
        Me.Txtparentemail.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Txtparentemail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtparentemail.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtparentemail.Location = New System.Drawing.Point(571, 156)
        Me.Txtparentemail.Multiline = True
        Me.Txtparentemail.Name = "Txtparentemail"
        Me.Txtparentemail.Size = New System.Drawing.Size(295, 30)
        Me.Txtparentemail.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(415, 162)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 13)
        Me.Label5.TabIndex = 211
        Me.Label5.Text = "PARENT EMAIL"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(411, 206)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(157, 13)
        Me.Label10.TabIndex = 203
        Me.Label10.Text = "DAY STUDENT/ BORDER"
        '
        'cmddayborder
        '
        Me.cmddayborder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmddayborder.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmddayborder.FormattingEnabled = True
        Me.cmddayborder.Items.AddRange(New Object() {"Day Student", "Border"})
        Me.cmddayborder.Location = New System.Drawing.Point(571, 197)
        Me.cmddayborder.Name = "cmddayborder"
        Me.cmddayborder.Size = New System.Drawing.Size(138, 25)
        Me.cmddayborder.TabIndex = 12
        '
        'dgw
        '
        Me.dgw.AllowUserToAddRows = False
        Me.dgw.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FloralWhite
        Me.dgw.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgw.BackgroundColor = System.Drawing.Color.White
        Me.dgw.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.Gainsboro
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Verdana", 9.0!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgw.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgw.ColumnHeadersHeight = 31
        Me.dgw.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column14, Me.CustomerID, Me.Column1, Me.Column10, Me.Column7, Me.Column8, Me.Column15, Me.Column13})
        Me.dgw.Cursor = System.Windows.Forms.Cursors.Hand
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Verdana", 9.0!)
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgw.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgw.EnableHeadersVisualStyles = False
        Me.dgw.GridColor = System.Drawing.Color.Black
        Me.dgw.Location = New System.Drawing.Point(12, 285)
        Me.dgw.MultiSelect = False
        Me.dgw.Name = "dgw"
        Me.dgw.ReadOnly = True
        Me.dgw.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.CadetBlue
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Verdana", 9.0!)
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DarkSlateGray
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgw.RowHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgw.RowHeadersWidth = 25
        Me.dgw.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.Transparent
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black
        Me.dgw.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.dgw.RowTemplate.Height = 18
        Me.dgw.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgw.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgw.Size = New System.Drawing.Size(894, 306)
        Me.dgw.TabIndex = 212
        '
        'Column14
        '
        Me.Column14.HeaderText = "Admission Number"
        Me.Column14.Name = "Column14"
        Me.Column14.ReadOnly = True
        '
        'CustomerID
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FloralWhite
        Me.CustomerID.DefaultCellStyle = DataGridViewCellStyle3
        Me.CustomerID.HeaderText = "Fullname"
        Me.CustomerID.Name = "CustomerID"
        Me.CustomerID.ReadOnly = True
        Me.CustomerID.Width = 140
        '
        'Column1
        '
        Me.Column1.HeaderText = "Sex"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'Column10
        '
        Me.Column10.HeaderText = "Class"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "L.G.A"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        Me.Column8.HeaderText = "State"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column15
        '
        Me.Column15.HeaderText = "phone"
        Me.Column15.Name = "Column15"
        Me.Column15.ReadOnly = True
        '
        'Column13
        '
        Me.Column13.HeaderText = "Day/Border Student"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        Me.Column13.Width = 130
        '
        'ibltotal
        '
        Me.ibltotal.AutoSize = True
        Me.ibltotal.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ibltotal.Location = New System.Drawing.Point(604, 594)
        Me.ibltotal.Name = "ibltotal"
        Me.ibltotal.Size = New System.Drawing.Size(19, 19)
        Me.ibltotal.TabIndex = 217
        Me.ibltotal.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(309, 594)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(285, 19)
        Me.Label8.TabIndex = 216
        Me.Label8.Text = "Number of Registered Student(s):"
        '
        'Btnrefresh
        '
        Me.Btnrefresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btnrefresh.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnrefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btnrefresh.Location = New System.Drawing.Point(928, 451)
        Me.Btnrefresh.Name = "Btnrefresh"
        Me.Btnrefresh.Size = New System.Drawing.Size(60, 28)
        Me.Btnrefresh.TabIndex = 215
        Me.Btnrefresh.Text = "Refresh"
        Me.Btnrefresh.UseVisualStyleBackColor = True
        '
        'btnregister
        '
        Me.btnregister.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnregister.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnregister.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnregister.Location = New System.Drawing.Point(928, 410)
        Me.btnregister.Name = "btnregister"
        Me.btnregister.Size = New System.Drawing.Size(60, 28)
        Me.btnregister.TabIndex = 213
        Me.btnregister.Text = "Register"
        Me.btnregister.UseVisualStyleBackColor = True
        '
        'btncancel
        '
        Me.btncancel.BackColor = System.Drawing.Color.White
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btncancel.Location = New System.Drawing.Point(928, 489)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(82, 28)
        Me.btncancel.TabIndex = 214
        Me.btncancel.Text = "   &Cancel"
        Me.btncancel.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.Computerized_grading__system.My.Resources.Resources.users3
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Image = Global.Computerized_grading__system.My.Resources.Resources.users3
        Me.PictureBox1.Location = New System.Drawing.Point(887, 10)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(120, 143)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 195
        Me.PictureBox1.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(309, 196)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(56, 13)
        Me.Label14.TabIndex = 219
        Me.Label14.Text = "3B or 1A"
        '
        'Register
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOrange
        Me.ClientSize = New System.Drawing.Size(1022, 624)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.ibltotal)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Btnrefresh)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnregister)
        Me.Controls.Add(Me.dgw)
        Me.Controls.Add(Me.Txtparentemail)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cmdstate)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtparentphone)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtdatebirth)
        Me.Controls.Add(Me.cmddayborder)
        Me.Controls.Add(Me.cmdsex)
        Me.Controls.Add(Me.txtadmissionnumber)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.upload)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtclass)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtparentoccupation)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtlga)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtparentname)
        Me.Controls.Add(Me.txtaddress)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtstudname)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Register"
        Me.Text = "Register Student"
        CType(Me.dgw, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents cmdsex As System.Windows.Forms.ComboBox
    Friend WithEvents txtadmissionnumber As System.Windows.Forms.TextBox
    Friend WithEvents upload As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtparentoccupation As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtlga As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtparentname As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtstudname As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents cmdstate As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtaddress As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtclass As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtdatebirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtparentphone As System.Windows.Forms.TextBox
    Friend WithEvents Txtparentemail As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cmddayborder As System.Windows.Forms.ComboBox
    Friend WithEvents dgw As System.Windows.Forms.DataGridView
    Friend WithEvents ibltotal As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Btnrefresh As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnregister As System.Windows.Forms.Button
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustomerID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label14 As System.Windows.Forms.Label
End Class
