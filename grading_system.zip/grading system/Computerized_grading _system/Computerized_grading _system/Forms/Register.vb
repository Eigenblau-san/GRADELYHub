﻿Imports System.Data.OleDb
Imports System.IO

Public Class Register
    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Me.Close()
    End Sub
    Private Sub Register_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Left = (Screen.PrimaryScreen.WorkingArea.Width - Me.Width) / 2
        Me.Top = (Screen.PrimaryScreen.WorkingArea.Height - Me.Height) / 2
        count()
        getadmnumber()
        clear()
        getrecord()

    End Sub
    Sub count()
        ConnDB()
        Dim sql As String = "select COUNT (*) FROM register"
        Dim cmd As New OleDbCommand(sql, conn)
        dr = cmd.ExecuteReader()
        While (dr.Read())
            ibltotal.Text = (dr(0).ToString())
        End While
    End Sub
    Private Sub getadmnumber()
        Try
            Dim SalesID As New Random
            Dim numbers As Integer = SalesID.Next(1, 10000)
            Dim digitss As String = numbers.ToString("0000")
            txtadmissionnumber.Text = digitss
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub clear()
        txtstudname.Text = ""
        cmdsex.SelectedIndex = -1
        txtlga.Text = ""
        txtclass.Text = ""
        txtparentoccupation.Text = ""
        txtparentname.Text = ""
        Txtparentemail.Text = ""
        cmddayborder.SelectedIndex = -1
        txtaddress.Text = ""
        txtdatebirth.Text = Today
        txtdatebirth.Text = ""
        txtlga.Text = ""
        cmdstate.SelectedIndex = -1
        txtparentphone.Text = ""
        PictureBox1.Image = BackgroundImage
    End Sub
    Private Sub getrecord()
        Try
            sqL = "SELECT  * FROM register order by class"
            ConnDB()
            cmd = New OleDbCommand(sqL, conn)
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            Do While dr.Read = True
                dgw.Rows.Add(dr(12), dr(0), dr(1), dr(4), dr(5), dr(6), dr(9), dr(11))
            Loop
        Catch ex As Exception
        Finally
            cmd.Dispose()
            conn.Close()
        End Try
    End Sub
    Private Sub upload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles upload.Click
        Dim OpenFile As New OpenFileDialog()
        Try
            With OpenFile
                .FileName = ""
                .Title = "Upload Student Photo..."
                .Filter = "Image file (*.jpg)|*.jpg|(*.png)|*.png|(*.jpeg)|*.jpeg|(*.giff)|*.giff| All Files (*.*)|*.*"

                If .ShowDialog = Windows.Forms.DialogResult.OK Then
                    Me.PictureBox1.Image = System.Drawing.Bitmap.FromFile(.FileName)
                Else
                End If
            End With
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try
    End Sub
    Private Sub registerstudent()
        Try
            ConnDB()
            Dim cmd As New OleDbCommand("INSERT INTO register VALUES(@fullName,@sex,@datebirth,@address,@class,@lga,@state,@parentname,@occupation,@phone,@email,@dayborder,@admissionnumber,@photo)", conn)
            cmd.Parameters.AddWithValue("@fullName", txtstudname.Text)
            cmd.Parameters.AddWithValue("@sex", cmdsex.Text)
            cmd.Parameters.AddWithValue("@datebirth", txtdatebirth.Text)
            cmd.Parameters.AddWithValue("@address", txtaddress.Text)
            cmd.Parameters.AddWithValue("@class", txtclass.Text)
            cmd.Parameters.AddWithValue("@lga", txtlga.Text)
            cmd.Parameters.AddWithValue("@state", cmdstate.Text)
            cmd.Parameters.AddWithValue("@parentname", txtparentname.Text)
            cmd.Parameters.AddWithValue("@occupation", txtparentoccupation.Text)
            cmd.Parameters.AddWithValue("@phone", txtparentphone.Text)
            cmd.Parameters.AddWithValue("@email", Txtparentemail.Text)
            cmd.Parameters.AddWithValue("@dayborder", cmddayborder.Text)
            cmd.Parameters.AddWithValue("@admissionnumber", txtadmissionnumber.Text)

            Dim ms As New MemoryStream()
            PictureBox1.Image.Save(ms, Imaging.ImageFormat.Jpeg)
            '    Picphoto.Image.Save(ms, Picphoto.Image.RawFormat)
            Dim data As Byte() = ms.GetBuffer()
            Dim p As New OleDbParameter("@photo", OleDbType.Binary)
            p.Value = data
            cmd.Parameters.Add(p)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Student Was Registered Successfully", "Database Report", MessageBoxButtons.OK)
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try
    End Sub
    Private Sub btnregister_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnregister.Click
        Try
            If txtstudname.Text = "" Then
                MsgBox("Enter Student Name field", MsgBoxStyle.Information, "Validation")
                txtstudname.Focus()
                Exit Sub
            ElseIf cmdsex.Text = "" Then
                MsgBox("Please Choose Sex field", MsgBoxStyle.Information, "Validation")
                cmdsex.Focus()
                Exit Sub
            ElseIf txtaddress.Text = "" Then
                MsgBox("Please Address field", MsgBoxStyle.Information, "Validation")
                txtaddress.Focus()
                Exit Sub
            ElseIf txtaddress.Text = "" Then
                MsgBox("Please Enter Address field", MsgBoxStyle.Information, "Validation")
                txtaddress.Focus()
                Exit Sub
            ElseIf txtclass.Text = "" Then
                MsgBox("Please Enter Class field", MsgBoxStyle.Information, "Validation")
                txtclass.Focus()
                Exit Sub
            ElseIf txtlga.Text = "" Then
                MsgBox("Please Enter LGA field", MsgBoxStyle.Information, "Validation")
                txtlga.Focus()
                Exit Sub
            ElseIf cmdstate.Text = "" Then
                MsgBox("Please Enter State field", MsgBoxStyle.Information, "Validation")
                cmdstate.Focus()
                Exit Sub
            ElseIf txtparentphone.Text = "" Then
                MsgBox("Please Parent Phone field", MsgBoxStyle.Information, "Validation")
                txtparentphone.Focus()
                Exit Sub
            ElseIf Txtparentemail.Text = "" Then
                MsgBox("Please Enter Parent Email field", MsgBoxStyle.Information, "Validation")
                Txtparentemail.Focus()
                Exit Sub
            ElseIf txtparentoccupation.Text = "" Then
                MsgBox("Please Enter Parent Occupation field", MsgBoxStyle.Information, "Validation")
                txtparentoccupation.Focus()
                Exit Sub
            ElseIf cmddayborder.Text = "" Then
                MsgBox("Please Choose Day/Border field", MsgBoxStyle.Information, "Validation")
                cmddayborder.Focus()
                Exit Sub
            End If
        registerstudent()
        clear()
        getrecord()
            getadmnumber()
            count()
        Catch ex As Exception
        End Try
    End Sub
    Private Sub txtclass_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtclass.TextChanged
        txtclass.Text.ToUpper()
    End Sub
    Private Sub Btnrefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnrefresh.Click
        clear()
        getadmnumber()
        getrecord()
    End Sub
End Class