﻿Imports System.Data.OleDb

Public Class View_Student
    Private Sub View_Student_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Left = (Screen.PrimaryScreen.WorkingArea.Width - Me.Width) / 2
        Me.Top = (Screen.PrimaryScreen.WorkingArea.Height - Me.Height) / 2
    End Sub
    Sub clear()
        txtstudname.Text = ""
        cmdsex.Text = ""
        txtlga.Text = ""
        txtclass.Text = ""
        txtparentoccupation.Text = ""
        txtparentname.Text = ""
        Txtparentemail.Text = ""
        cmddayborder.Text = ""
        txtaddress.Text = ""
        txtdatebirth.Text = Today
        txtdatebirth.Text = ""
        txtlga.Text = ""
        cmdstate.Text = ""
        txtparentphone.Text = ""
        PictureBox1.Image = BackgroundImage
    End Sub
    Private Sub userpic()
        Try
            ConnDB()
            Dim arrImage() As Byte
            Dim myMS As New IO.MemoryStream
            Dim da As New OleDbDataAdapter(("select * from register where admnumber='" & Trim(txtadmissionnumber.Text) & "'"), conn)

            Dim dt As New DataTable
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                If Not IsDBNull(dt.Rows(0).Item("photo")) Then
                    arrImage = dt.Rows(0).Item("photo")
                    For Each ar As Byte In arrImage
                        myMS.WriteByte(ar)
                    Next
                    Me.PictureBox1.Image = System.Drawing.Image.FromStream(myMS)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub getrecord()
        Try
            ConnDB()
            Dim da As New OleDbDataAdapter(("select * from register where admnumber='" & Trim(txtadmissionnumber.Text) & "'"), conn)
            Dim dt As New DataTable
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                Me.txtstudname.Text = dt.Rows(0).Item("studname") & ""
                Me.cmdsex.Text = dt.Rows(0).Item("sex") & ""
                Me.txtaddress.Text = dt.Rows(0).Item("address") & ""
                Me.txtdatebirth.Text = dt.Rows(0).Item("datebirth") & ""
                Me.txtparentoccupation.Text = dt.Rows(0).Item("parentoccupation") & ""
                Me.txtparentphone.Text = dt.Rows(0).Item("parentphone") & ""
                Me.Txtparentemail.Text = dt.Rows(0).Item("parentemail") & ""
                Me.txtparentname.Text = dt.Rows(0).Item("parentname") & ""
                Me.txtlga.Text = dt.Rows(0).Item("lga") & ""
                Me.cmdstate.Text = dt.Rows(0).Item("state") & ""
                Me.txtclass.Text = dt.Rows(0).Item("class") & ""
                Me.cmddayborder.Text = dt.Rows(0).Item("daystudentborder") & ""
            End If
            userpic()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        getrecord()
    End Sub
    Private Sub Deleteuser()
        Try
            sqL = "DELETE * FROM register WHERE admnumber='" & Trim(txtadmissionnumber.Text) & "'"
            ConnDB()
            cmd = New OleDbCommand(sqL, conn)
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Dispose()
            conn.Close()
        End Try
    End Sub
    Private Sub updaterecord()
        Try
            sqL = "UPDATE register SET studname = '" & txtstudname.Text & "', sex = '" & cmdsex.Text & "',datebirth = '" & txtdatebirth.Text & "', address = '" & txtaddress.Text & "', parentemail = '" & Txtparentemail.Text & "',parentoccupation = '" & txtparentoccupation.Text & "',parentphone = '" & txtparentphone.Text & "', parentname = '" & txtparentname.Text & "',lga = '" & txtlga.Text & "',state = '" & cmdstate.Text & "', daystudentborder = '" & cmddayborder.Text & "' WHERE admnumber = '" & txtadmissionnumber.Text & "'"
            ConnDB()
            cmd = New OleDbCommand(sqL, conn)
            Dim i As Integer
            i = cmd.ExecuteNonQuery
            If i > 0 Then
                MsgBox("Student info Successfully Updated", MsgBoxStyle.Information, "Update Student info")
            Else
                MsgBox("Failed in Updating Student info", MsgBoxStyle.Information, "Update Student info")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Dispose()
            conn.Close()
        End Try
    End Sub
    Private Sub Btndelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btndelete.Click
        If MsgBox("Are you sure you want to Delete this Student", MsgBoxStyle.YesNo, "Validation") = MsgBoxResult.Yes Then
            Deleteuser()
            clear()
        End If
    End Sub
    Private Sub btnedit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnedit.Click
        updaterecord()
    End Sub
    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Me.Close()
    End Sub
    Private Sub Btnrefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnrefresh.Click

    End Sub
End Class