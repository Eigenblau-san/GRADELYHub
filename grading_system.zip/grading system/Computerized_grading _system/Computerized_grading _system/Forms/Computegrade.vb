﻿Imports System.Data.OleDb

Public Class Computegrade

    Private Sub Computegrade_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Left = (Screen.PrimaryScreen.WorkingArea.Width - Me.Width) / 2
        Me.Top = (Screen.PrimaryScreen.WorkingArea.Height - Me.Height) / 2
    End Sub
    Private Sub userpic()
        Try
            ConnDB()
            Dim arrImage() As Byte
            Dim myMS As New IO.MemoryStream
            Dim da As New OleDbDataAdapter(("select * from register where admnumber='" & Trim(txtadmissionnumber.Text) & "'"), conn)

            Dim dt As New DataTable
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                If Not IsDBNull(dt.Rows(0).Item("photo")) Then
                    arrImage = dt.Rows(0).Item("photo")
                    For Each ar As Byte In arrImage
                        myMS.WriteByte(ar)
                    Next
                    Me.PictureBox1.Image = System.Drawing.Image.FromStream(myMS)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub getrecord()
        Try
            ConnDB()
            Dim da As New OleDbDataAdapter(("select * from register where admnumber='" & Trim(txtadmissionnumber.Text) & "'"), conn)
            Dim dt As New DataTable
            da.Fill(dt)
            If dt.Rows.Count > 0 Then
                Me.txtstudname.Text = dt.Rows(0).Item("studname") & ""
                Me.txtclass.Text = dt.Rows(0).Item("class") & ""
                userpic()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub txtadmissionnumber_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtadmissionnumber.TextChanged
        getrecord()
    End Sub
    Sub clear()
        txtadmissionnumber.Text = ""
        txtstudname.Text = ""
        txtclass.Text = ""
        txtsession.Text = ""
        cmdterm.Text = ""
        cmbcourse1.Text = ""
        score1.Text = ""
        remark1.Text = ""
        cmbcourse2.Text = ""
        score2.Text = ""
        remark2.Text = ""
        cmbcourse3.Text = ""
        score3.Text = ""
        remark3.Text = ""
        cmbcourse4.Text = ""
        score4.Text = ""
        remark4.Text = ""
        cmbcourse5.Text = ""
        score5.Text = ""
        remark5.Text = ""
        cmbcourse6.Text = ""
        score6.Text = ""
        remark6.Text = ""
        cmbcourse7.Text = ""
        score7.Text = ""
        remark7.Text = ""
        txttotalscores.Text = ""
        txtremark.Text = ""
        txtaverage.Text = ""
        result1.Text = ""
        result2.Text = ""
        result3.Text = ""
        result4.Text = ""
        result5.Text = ""
        result6.Text = ""
        result7.Text = ""
        PictureBox1.Image = BackgroundImage
        cmdterm.SelectedIndex = -1
    End Sub
    Private Sub saveresult()
        Try
            ConnDB()
            Dim cmd As New OleDbCommand("INSERT INTO grade VALUES(@admnum,@studname,@class,@session,@term,@course1,@score1,@remark1,@course2,@score2,@remark2,@course3,@score3,@remark3,@course4,@score4,@remark4,@course5,@score5,@remark5,@course6,@score6,@remark6,@course7,@score7,@remark7,totalscores,@remark,@average)", conn)
            cmd.Parameters.AddWithValue("@admnum", txtadmissionnumber.Text)
            cmd.Parameters.AddWithValue("@studname", txtstudname.Text)
            cmd.Parameters.AddWithValue("@class", txtclass.Text)
            cmd.Parameters.AddWithValue("@session", txtsession.Text)
            cmd.Parameters.AddWithValue("@term", cmdterm.Text)
            cmd.Parameters.AddWithValue("@course1", cmbcourse1.Text)
            cmd.Parameters.AddWithValue("@score1", score1.Text)
            cmd.Parameters.AddWithValue("@remark1", remark1.Text)
            cmd.Parameters.AddWithValue("@course2", cmbcourse2.Text)
            cmd.Parameters.AddWithValue("@score2", score2.Text)
            cmd.Parameters.AddWithValue("@remark2", remark2.Text)
            cmd.Parameters.AddWithValue("@course3", cmbcourse3.Text)
            cmd.Parameters.AddWithValue("@score3", score3.Text)
            cmd.Parameters.AddWithValue("@remark3", remark3.Text)
            cmd.Parameters.AddWithValue("@course4", cmbcourse4.Text)
            cmd.Parameters.AddWithValue("@score4", score4.Text)
            cmd.Parameters.AddWithValue("@remark", remark4.Text)
            cmd.Parameters.AddWithValue("@course5", cmbcourse5.Text)
            cmd.Parameters.AddWithValue("@score5", score5.Text)
            cmd.Parameters.AddWithValue("@remark5", remark5.Text)
            cmd.Parameters.AddWithValue("@course6", cmbcourse6.Text)
            cmd.Parameters.AddWithValue("@score6", score6.Text)
            cmd.Parameters.AddWithValue("@remark6", remark6.Text)
            cmd.Parameters.AddWithValue("@course7", cmbcourse7.Text)
            cmd.Parameters.AddWithValue("@score7", score7.Text)
            cmd.Parameters.AddWithValue("@remark7", remark7.Text)
            cmd.Parameters.AddWithValue("@totalscores", txttotalscores.Text)
            cmd.Parameters.AddWithValue("@remark", txtremark.Text)
            cmd.Parameters.AddWithValue("@average", txtaverage.Text)

            cmd.ExecuteNonQuery()
            MessageBox.Show("Student Result Was Registered Successfully", "Database Report", MessageBoxButtons.OK)
            clear()
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try
    End Sub
    Private Sub score1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles score1.TextChanged
        Try
            result1.Text = (cmbcourse1.Text & "   = " & score1.Text)
            If score1.Text <= 45 Then
                remark1.Text = "FAIL"
            ElseIf score1.Text <= 49 Then
                remark1.Text = "WEAK PASS"
            ElseIf score1.Text <= 54 Then
                remark1.Text = "STRONG PASS"
            ElseIf score1.Text <= 59 Then
                remark1.Text = "FAIR"
            ElseIf score1.Text <= 64 Then
                remark1.Text = "MERIT"
            ElseIf score1.Text <= 69 Then
                remark1.Text = "CREDIT"
            ElseIf score1.Text <= 74 Then
                remark1.Text = "GOOD"
            ElseIf score1.Text <= 79 Then
                remark1.Text = "VERY GOOD"
            ElseIf score1.Text <= 100 Then
                remark1.Text = "EXCELLENT"
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub score2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles score2.TextChanged
        Try
            result2.Text = (cmbcourse2.Text & "   = " & score2.Text)
            If score2.Text <= 45 Then
                remark2.Text = "FAIL"
            ElseIf score2.Text <= 49 Then
                remark2.Text = "WEAK PASS"
            ElseIf score2.Text <= 54 Then
                remark2.Text = "STRONG PASS"
            ElseIf score2.Text <= 59 Then
                remark2.Text = "FAIR"
            ElseIf score2.Text <= 64 Then
                remark2.Text = "MERIT"
            ElseIf score2.Text <= 69 Then
                remark2.Text = "CREDIT"
            ElseIf score2.Text <= 74 Then
                remark2.Text = "GOOD"
            ElseIf score2.Text <= 79 Then
                remark2.Text = "VERY GOOD"
            ElseIf score2.Text <= 100 Then
                remark2.Text = "EXCELLENT"
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub score3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles score3.TextChanged
        Try
            result3.Text = (cmbcourse3.Text & "   = " & score3.Text)
            If score3.Text <= 45 Then
                remark3.Text = "FAIL"
            ElseIf score3.Text <= 49 Then
                remark3.Text = "WEAK PASS"
            ElseIf score3.Text <= 54 Then
                remark3.Text = "STRONG PASS"
            ElseIf score3.Text <= 59 Then
                remark3.Text = "FAIR"
            ElseIf score3.Text <= 64 Then
                remark3.Text = "MERIT"
            ElseIf score3.Text <= 69 Then
                remark3.Text = "CREDIT"
            ElseIf score3.Text <= 74 Then
                remark3.Text = "GOOD"
            ElseIf score3.Text <= 79 Then
                remark3.Text = "VERY GOOD"
            ElseIf score3.Text <= 100 Then
                remark3.Text = "EXCELLENT"
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub score4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles score4.TextChanged
        Try
            result4.Text = (cmbcourse4.Text & "   = " & score4.Text)
            If score4.Text <= 45 Then
                remark4.Text = "FAIL"
            ElseIf score4.Text <= 49 Then
                remark4.Text = "WEAK PASS"
            ElseIf score4.Text <= 54 Then
                remark4.Text = "STRONG PASS"
            ElseIf score4.Text <= 59 Then
                remark4.Text = "FAIR"
            ElseIf score4.Text <= 64 Then
                remark4.Text = "MERIT"
            ElseIf score4.Text <= 69 Then
                remark4.Text = "CREDIT"
            ElseIf score4.Text <= 74 Then
                remark4.Text = "GOOD"
            ElseIf score4.Text <= 79 Then
                remark4.Text = "VERY GOOD"
            ElseIf score4.Text <= 100 Then
                remark4.Text = "EXCELLENT"
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub score5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles score5.TextChanged
        Try
            result5.Text = (cmbcourse5.Text & "   = " & score5.Text)
            If score5.Text <= 45 Then
                remark5.Text = "FAIL"
            ElseIf score5.Text <= 49 Then
                remark5.Text = "WEAK PASS"
            ElseIf score5.Text <= 54 Then
                remark5.Text = "STRONG PASS"
            ElseIf score5.Text <= 59 Then
                remark5.Text = "FAIR"
            ElseIf score5.Text <= 64 Then
                remark5.Text = "MERIT"
            ElseIf score5.Text <= 69 Then
                remark5.Text = "CREDIT"
            ElseIf score5.Text <= 74 Then
                remark5.Text = "GOOD"
            ElseIf score5.Text <= 79 Then
                remark5.Text = "VERY GOOD"
            ElseIf score5.Text <= 100 Then
                remark5.Text = "EXCELLENT"
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub score6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles score6.TextChanged
        Try
            result6.Text = (cmbcourse6.Text & "   = " & score6.Text)
            If score6.Text <= 45 Then
                remark6.Text = "FAIL"
            ElseIf score6.Text <= 49 Then
                remark6.Text = "WEAK PASS"
            ElseIf score6.Text <= 54 Then
                remark6.Text = "STRONG PASS"
            ElseIf score6.Text <= 59 Then
                remark6.Text = "FAIR"
            ElseIf score6.Text <= 64 Then
                remark6.Text = "MERIT"
            ElseIf score6.Text <= 69 Then
                remark6.Text = "CREDIT"
            ElseIf score6.Text <= 74 Then
                remark6.Text = "GOOD"
            ElseIf score6.Text <= 79 Then
                remark6.Text = "VERY GOOD"
            ElseIf score6.Text <= 100 Then
                remark6.Text = "EXCELLENT"
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub score7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles score7.TextChanged
        Try
            result7.Text = (cmbcourse7.Text & "   = " & score7.Text)
            If score7.Text <= 45 Then
                remark7.Text = "FAIL"
            ElseIf score7.Text <= 49 Then
                remark7.Text = "WEAK PASS"
            ElseIf score7.Text <= 54 Then
                remark7.Text = "STRONG PASS"
            ElseIf score7.Text <= 59 Then
                remark7.Text = "FAIR"
            ElseIf score7.Text <= 64 Then
                remark7.Text = "MERIT"
            ElseIf score7.Text <= 69 Then
                remark7.Text = "CREDIT"
            ElseIf score7.Text <= 74 Then
                remark7.Text = "GOOD"
            ElseIf score7.Text <= 79 Then
                remark7.Text = "VERY GOOD"
            ElseIf score7.Text <= 100 Then
                remark7.Text = "EXCELLENT"
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub txtaverage_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtaverage.TextChanged
        Try

            If txtaverage.Text <= 45 Then
                txtremark.Text = "YOU HAVE FAIL, PUT MORE EFFORT"
            ElseIf txtaverage.Text <= 50 Then
                txtremark.Text = "YOU HAVE A FAIR RESULT"
            ElseIf txtaverage.Text <= 70 Then
                txtremark.Text = "YOU HAVE A GOOD RESULT"
            ElseIf txtaverage.Text <= 100 Then
                txtremark.Text = "YOU HAVE AN EXCELLENT RESULT"
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub validateresult()
        Try
            sqL = "SELECT * FROM grade WHERE admnumber = '" & txtadmissionnumber.Text & "' AND session1 = '" & txtsession.Text & "' AND term = '" & cmdterm.Text & "' "
            ConnDB()
            cmd = New OleDbCommand(sqL, conn)
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            If dr.HasRows Then
                MsgBox("You Have Already Save Result For this Student")
            Else
                saveresult()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cmd.Dispose()
            conn.Close()
        End Try
    End Sub
    Private Sub btncompute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncompute.Click
        txttotalscores.Text = Val(score1.Text) + Val(score2.Text) + Val(score3.Text) + Val(score4.Text) + Val(score5.Text) + Val(score6.Text) + Val(score7.Text)
        txtaverage.Text = (txttotalscores.Text / 7)
    End Sub
    Private Sub btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub
    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        validateresult()
    End Sub
    Private Sub btnreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreset.Click
        clear()
    End Sub

    Private Sub txttotalscores_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttotalscores.TextChanged

    End Sub
End Class