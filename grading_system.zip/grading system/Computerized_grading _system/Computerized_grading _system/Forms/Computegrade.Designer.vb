﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Computegrade
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Computegrade))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtadmissionnumber = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtstudname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtclass = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtsession = New System.Windows.Forms.TextBox()
        Me.cmdterm = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.result7 = New System.Windows.Forms.Label()
        Me.result6 = New System.Windows.Forms.Label()
        Me.result5 = New System.Windows.Forms.Label()
        Me.result4 = New System.Windows.Forms.Label()
        Me.result3 = New System.Windows.Forms.Label()
        Me.result2 = New System.Windows.Forms.Label()
        Me.result1 = New System.Windows.Forms.Label()
        Me.remark7 = New System.Windows.Forms.Label()
        Me.score7 = New System.Windows.Forms.TextBox()
        Me.cmbcourse7 = New System.Windows.Forms.ComboBox()
        Me.remark6 = New System.Windows.Forms.Label()
        Me.remark5 = New System.Windows.Forms.Label()
        Me.remark4 = New System.Windows.Forms.Label()
        Me.remark3 = New System.Windows.Forms.Label()
        Me.remark2 = New System.Windows.Forms.Label()
        Me.remark1 = New System.Windows.Forms.Label()
        Me.score6 = New System.Windows.Forms.TextBox()
        Me.score5 = New System.Windows.Forms.TextBox()
        Me.score4 = New System.Windows.Forms.TextBox()
        Me.score3 = New System.Windows.Forms.TextBox()
        Me.score2 = New System.Windows.Forms.TextBox()
        Me.score1 = New System.Windows.Forms.TextBox()
        Me.cmbcourse6 = New System.Windows.Forms.ComboBox()
        Me.cmbcourse5 = New System.Windows.Forms.ComboBox()
        Me.cmbcourse4 = New System.Windows.Forms.ComboBox()
        Me.cmbcourse3 = New System.Windows.Forms.ComboBox()
        Me.cmbcourse2 = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbcourse1 = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtremark = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtaverage = New System.Windows.Forms.TextBox()
        Me.txttotalscores = New System.Windows.Forms.TextBox()
        Me.btnreset = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.btncompute = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.Computerized_grading__system.My.Resources.Resources.users3
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Image = Global.Computerized_grading__system.My.Resources.Resources.users3
        Me.PictureBox1.Location = New System.Drawing.Point(874, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(120, 143)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 240
        Me.PictureBox1.TabStop = False
        '
        'txtadmissionnumber
        '
        Me.txtadmissionnumber.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtadmissionnumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtadmissionnumber.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadmissionnumber.Location = New System.Drawing.Point(139, 20)
        Me.txtadmissionnumber.Multiline = True
        Me.txtadmissionnumber.Name = "txtadmissionnumber"
        Me.txtadmissionnumber.Size = New System.Drawing.Size(140, 30)
        Me.txtadmissionnumber.TabIndex = 243
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(10, 30)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(125, 13)
        Me.Label9.TabIndex = 244
        Me.Label9.Text = "ADMISION NUMBER"
        '
        'txtstudname
        '
        Me.txtstudname.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtstudname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtstudname.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstudname.Location = New System.Drawing.Point(139, 56)
        Me.txtstudname.Multiline = True
        Me.txtstudname.Name = "txtstudname"
        Me.txtstudname.ReadOnly = True
        Me.txtstudname.Size = New System.Drawing.Size(238, 30)
        Me.txtstudname.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 13)
        Me.Label1.TabIndex = 242
        Me.Label1.Text = "STUDENT NAME"
        '
        'txtclass
        '
        Me.txtclass.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtclass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclass.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclass.Location = New System.Drawing.Point(140, 92)
        Me.txtclass.Multiline = True
        Me.txtclass.Name = "txtclass"
        Me.txtclass.ReadOnly = True
        Me.txtclass.Size = New System.Drawing.Size(139, 30)
        Me.txtclass.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 102)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 246
        Me.Label2.Text = "CLASS"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(387, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 13)
        Me.Label4.TabIndex = 250
        Me.Label4.Text = "TERM"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(385, 28)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(61, 13)
        Me.Label5.TabIndex = 252
        Me.Label5.Text = "SESSION"
        '
        'txtsession
        '
        Me.txtsession.AcceptsReturn = True
        Me.txtsession.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.txtsession.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsession.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsession.Location = New System.Drawing.Point(447, 19)
        Me.txtsession.Multiline = True
        Me.txtsession.Name = "txtsession"
        Me.txtsession.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.txtsession.Size = New System.Drawing.Size(139, 30)
        Me.txtsession.TabIndex = 3
        '
        'cmdterm
        '
        Me.cmdterm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmdterm.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdterm.FormattingEnabled = True
        Me.cmdterm.Items.AddRange(New Object() {"First", "Second", "Third"})
        Me.cmdterm.Location = New System.Drawing.Point(447, 58)
        Me.cmdterm.Name = "cmdterm"
        Me.cmdterm.Size = New System.Drawing.Size(138, 25)
        Me.cmdterm.TabIndex = 4
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.PictureBox3)
        Me.GroupBox2.Controls.Add(Me.PictureBox2)
        Me.GroupBox2.Controls.Add(Me.PictureBox11)
        Me.GroupBox2.Controls.Add(Me.result7)
        Me.GroupBox2.Controls.Add(Me.result6)
        Me.GroupBox2.Controls.Add(Me.result5)
        Me.GroupBox2.Controls.Add(Me.result4)
        Me.GroupBox2.Controls.Add(Me.result3)
        Me.GroupBox2.Controls.Add(Me.result2)
        Me.GroupBox2.Controls.Add(Me.result1)
        Me.GroupBox2.Controls.Add(Me.remark7)
        Me.GroupBox2.Controls.Add(Me.score7)
        Me.GroupBox2.Controls.Add(Me.cmbcourse7)
        Me.GroupBox2.Controls.Add(Me.remark6)
        Me.GroupBox2.Controls.Add(Me.remark5)
        Me.GroupBox2.Controls.Add(Me.remark4)
        Me.GroupBox2.Controls.Add(Me.remark3)
        Me.GroupBox2.Controls.Add(Me.remark2)
        Me.GroupBox2.Controls.Add(Me.remark1)
        Me.GroupBox2.Controls.Add(Me.score6)
        Me.GroupBox2.Controls.Add(Me.score5)
        Me.GroupBox2.Controls.Add(Me.score4)
        Me.GroupBox2.Controls.Add(Me.score3)
        Me.GroupBox2.Controls.Add(Me.score2)
        Me.GroupBox2.Controls.Add(Me.score1)
        Me.GroupBox2.Controls.Add(Me.cmbcourse6)
        Me.GroupBox2.Controls.Add(Me.cmbcourse5)
        Me.GroupBox2.Controls.Add(Me.cmbcourse4)
        Me.GroupBox2.Controls.Add(Me.cmbcourse3)
        Me.GroupBox2.Controls.Add(Me.cmbcourse2)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.cmbcourse1)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 169)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(924, 276)
        Me.GroupBox2.TabIndex = 254
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "COURSE INFO"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(569, 19)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(10, 238)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 257
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(447, 19)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(10, 238)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 256
        Me.PictureBox2.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Image)
        Me.PictureBox11.Location = New System.Drawing.Point(301, 19)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(10, 238)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox11.TabIndex = 255
        Me.PictureBox11.TabStop = False
        '
        'result7
        '
        Me.result7.AutoSize = True
        Me.result7.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.result7.Location = New System.Drawing.Point(590, 226)
        Me.result7.Name = "result7"
        Me.result7.Size = New System.Drawing.Size(56, 17)
        Me.result7.TabIndex = 65
        Me.result7.Text = "RESULT"
        '
        'result6
        '
        Me.result6.AutoSize = True
        Me.result6.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.result6.Location = New System.Drawing.Point(590, 195)
        Me.result6.Name = "result6"
        Me.result6.Size = New System.Drawing.Size(56, 17)
        Me.result6.TabIndex = 64
        Me.result6.Text = "RESULT"
        '
        'result5
        '
        Me.result5.AutoSize = True
        Me.result5.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.result5.Location = New System.Drawing.Point(590, 167)
        Me.result5.Name = "result5"
        Me.result5.Size = New System.Drawing.Size(56, 17)
        Me.result5.TabIndex = 63
        Me.result5.Text = "RESULT"
        '
        'result4
        '
        Me.result4.AutoSize = True
        Me.result4.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.result4.Location = New System.Drawing.Point(590, 137)
        Me.result4.Name = "result4"
        Me.result4.Size = New System.Drawing.Size(56, 17)
        Me.result4.TabIndex = 62
        Me.result4.Text = "RESULT"
        '
        'result3
        '
        Me.result3.AutoSize = True
        Me.result3.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.result3.Location = New System.Drawing.Point(590, 108)
        Me.result3.Name = "result3"
        Me.result3.Size = New System.Drawing.Size(56, 17)
        Me.result3.TabIndex = 61
        Me.result3.Text = "RESULT"
        '
        'result2
        '
        Me.result2.AutoSize = True
        Me.result2.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.result2.Location = New System.Drawing.Point(590, 78)
        Me.result2.Name = "result2"
        Me.result2.Size = New System.Drawing.Size(56, 17)
        Me.result2.TabIndex = 60
        Me.result2.Text = "RESULT"
        '
        'result1
        '
        Me.result1.AutoSize = True
        Me.result1.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.result1.Location = New System.Drawing.Point(590, 48)
        Me.result1.Name = "result1"
        Me.result1.Size = New System.Drawing.Size(56, 17)
        Me.result1.TabIndex = 59
        Me.result1.Text = "RESULT"
        '
        'remark7
        '
        Me.remark7.AutoSize = True
        Me.remark7.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.remark7.Location = New System.Drawing.Point(469, 230)
        Me.remark7.Name = "remark7"
        Me.remark7.Size = New System.Drawing.Size(64, 17)
        Me.remark7.TabIndex = 57
        Me.remark7.Text = "REMARK"
        '
        'score7
        '
        Me.score7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.score7.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score7.Location = New System.Drawing.Point(328, 223)
        Me.score7.Name = "score7"
        Me.score7.Size = New System.Drawing.Size(100, 25)
        Me.score7.TabIndex = 55
        '
        'cmbcourse7
        '
        Me.cmbcourse7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcourse7.FormattingEnabled = True
        Me.cmbcourse7.Items.AddRange(New Object() {"", "ENGLISH LANGUAGE", "MATHEMATICS", "INTEGRATED SCIENCE", "SOCIAL STUDIES", "CHRISTIAN RELIGOUS KNOWLEGDE", "FRENCH ", "EFIK", "IBIBIO", "HEALTH & PHYSICAL EDUCATION", "BUSINESS STUDIES", "COMPUTER SCIENCE", "PHYSICS", "CHEMISTRY", "BIOLOGY", "GEOGRAPHY", "LIIT-IN-ENGLISH", "GEOGRAPHY", "AGRICULTURAL SCIENCE"})
        Me.cmbcourse7.Location = New System.Drawing.Point(35, 230)
        Me.cmbcourse7.Name = "cmbcourse7"
        Me.cmbcourse7.Size = New System.Drawing.Size(215, 21)
        Me.cmbcourse7.TabIndex = 53
        '
        'remark6
        '
        Me.remark6.AutoSize = True
        Me.remark6.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.remark6.Location = New System.Drawing.Point(470, 195)
        Me.remark6.Name = "remark6"
        Me.remark6.Size = New System.Drawing.Size(64, 17)
        Me.remark6.TabIndex = 52
        Me.remark6.Text = "REMARK"
        '
        'remark5
        '
        Me.remark5.AutoSize = True
        Me.remark5.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.remark5.Location = New System.Drawing.Point(470, 167)
        Me.remark5.Name = "remark5"
        Me.remark5.Size = New System.Drawing.Size(64, 17)
        Me.remark5.TabIndex = 51
        Me.remark5.Text = "REMARK"
        '
        'remark4
        '
        Me.remark4.AutoSize = True
        Me.remark4.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.remark4.Location = New System.Drawing.Point(470, 139)
        Me.remark4.Name = "remark4"
        Me.remark4.Size = New System.Drawing.Size(64, 17)
        Me.remark4.TabIndex = 50
        Me.remark4.Text = "REMARK"
        '
        'remark3
        '
        Me.remark3.AutoSize = True
        Me.remark3.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.remark3.Location = New System.Drawing.Point(470, 109)
        Me.remark3.Name = "remark3"
        Me.remark3.Size = New System.Drawing.Size(64, 17)
        Me.remark3.TabIndex = 49
        Me.remark3.Text = "REMARK"
        '
        'remark2
        '
        Me.remark2.AutoSize = True
        Me.remark2.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.remark2.Location = New System.Drawing.Point(470, 76)
        Me.remark2.Name = "remark2"
        Me.remark2.Size = New System.Drawing.Size(64, 17)
        Me.remark2.TabIndex = 48
        Me.remark2.Text = "REMARK"
        '
        'remark1
        '
        Me.remark1.AutoSize = True
        Me.remark1.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.remark1.Location = New System.Drawing.Point(470, 46)
        Me.remark1.Name = "remark1"
        Me.remark1.Size = New System.Drawing.Size(64, 17)
        Me.remark1.TabIndex = 47
        Me.remark1.Text = "REMARK"
        '
        'score6
        '
        Me.score6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.score6.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score6.Location = New System.Drawing.Point(329, 190)
        Me.score6.Name = "score6"
        Me.score6.Size = New System.Drawing.Size(100, 25)
        Me.score6.TabIndex = 46
        '
        'score5
        '
        Me.score5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.score5.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score5.Location = New System.Drawing.Point(329, 160)
        Me.score5.Name = "score5"
        Me.score5.Size = New System.Drawing.Size(100, 25)
        Me.score5.TabIndex = 45
        '
        'score4
        '
        Me.score4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.score4.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score4.Location = New System.Drawing.Point(329, 132)
        Me.score4.Name = "score4"
        Me.score4.Size = New System.Drawing.Size(100, 25)
        Me.score4.TabIndex = 44
        '
        'score3
        '
        Me.score3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.score3.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score3.Location = New System.Drawing.Point(329, 102)
        Me.score3.Name = "score3"
        Me.score3.Size = New System.Drawing.Size(100, 25)
        Me.score3.TabIndex = 43
        '
        'score2
        '
        Me.score2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.score2.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score2.Location = New System.Drawing.Point(329, 71)
        Me.score2.Name = "score2"
        Me.score2.Size = New System.Drawing.Size(100, 25)
        Me.score2.TabIndex = 42
        '
        'score1
        '
        Me.score1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.score1.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.score1.Location = New System.Drawing.Point(329, 41)
        Me.score1.Name = "score1"
        Me.score1.Size = New System.Drawing.Size(100, 25)
        Me.score1.TabIndex = 41
        '
        'cmbcourse6
        '
        Me.cmbcourse6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcourse6.FormattingEnabled = True
        Me.cmbcourse6.Items.AddRange(New Object() {"", "ENGLISH LANGUAGE", "MATHEMATICS", "INTEGRATED SCIENCE", "SOCIAL STUDIES", "CHRISTIAN RELIGOUS KNOWLEGDE", "FRENCH ", "EFIK", "IBIBIO", "HEALTH & PHYSICAL EDUCATION", "BUSINESS STUDIES", "COMPUTER SCIENCE", "PHYSICS", "CHEMISTRY", "BIOLOGY", "GEOGRAPHY", "LIIT-IN-ENGLISH", "GEOGRAPHY", "AGRICULTURAL SCIENCE"})
        Me.cmbcourse6.Location = New System.Drawing.Point(36, 197)
        Me.cmbcourse6.Name = "cmbcourse6"
        Me.cmbcourse6.Size = New System.Drawing.Size(215, 21)
        Me.cmbcourse6.TabIndex = 32
        '
        'cmbcourse5
        '
        Me.cmbcourse5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcourse5.FormattingEnabled = True
        Me.cmbcourse5.Items.AddRange(New Object() {"", "ENGLISH LANGUAGE", "MATHEMATICS", "INTEGRATED SCIENCE", "SOCIAL STUDIES", "CHRISTIAN RELIGOUS KNOWLEGDE", "FRENCH ", "EFIK", "IBIBIO", "HEALTH & PHYSICAL EDUCATION", "BUSINESS STUDIES", "COMPUTER SCIENCE", "PHYSICS", "CHEMISTRY", "BIOLOGY", "GEOGRAPHY", "LIIT-IN-ENGLISH", "GEOGRAPHY", "AGRICULTURAL SCIENCE"})
        Me.cmbcourse5.Location = New System.Drawing.Point(36, 165)
        Me.cmbcourse5.Name = "cmbcourse5"
        Me.cmbcourse5.Size = New System.Drawing.Size(215, 21)
        Me.cmbcourse5.TabIndex = 29
        '
        'cmbcourse4
        '
        Me.cmbcourse4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcourse4.FormattingEnabled = True
        Me.cmbcourse4.Items.AddRange(New Object() {"", "ENGLISH LANGUAGE", "MATHEMATICS", "INTEGRATED SCIENCE", "SOCIAL STUDIES", "CHRISTIAN RELIGOUS KNOWLEGDE", "FRENCH ", "EFIK", "IBIBIO", "HEALTH & PHYSICAL EDUCATION", "BUSINESS STUDIES", "COMPUTER SCIENCE", "PHYSICS", "CHEMISTRY", "BIOLOGY", "GEOGRAPHY", "LIIT-IN-ENGLISH", "GEOGRAPHY", "AGRICULTURAL SCIENCE"})
        Me.cmbcourse4.Location = New System.Drawing.Point(36, 135)
        Me.cmbcourse4.Name = "cmbcourse4"
        Me.cmbcourse4.Size = New System.Drawing.Size(215, 21)
        Me.cmbcourse4.TabIndex = 26
        '
        'cmbcourse3
        '
        Me.cmbcourse3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcourse3.FormattingEnabled = True
        Me.cmbcourse3.Items.AddRange(New Object() {"", "ENGLISH LANGUAGE", "MATHEMATICS", "INTEGRATED SCIENCE", "SOCIAL STUDIES", "CHRISTIAN RELIGOUS KNOWLEGDE", "FRENCH ", "EFIK", "IBIBIO", "HEALTH & PHYSICAL EDUCATION", "BUSINESS STUDIES", "COMPUTER SCIENCE", "PHYSICS", "CHEMISTRY", "BIOLOGY", "GEOGRAPHY", "LIIT-IN-ENGLISH", "GEOGRAPHY", "AGRICULTURAL SCIENCE"})
        Me.cmbcourse3.Location = New System.Drawing.Point(36, 105)
        Me.cmbcourse3.Name = "cmbcourse3"
        Me.cmbcourse3.Size = New System.Drawing.Size(215, 21)
        Me.cmbcourse3.TabIndex = 23
        '
        'cmbcourse2
        '
        Me.cmbcourse2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcourse2.FormattingEnabled = True
        Me.cmbcourse2.Items.AddRange(New Object() {"", "ENGLISH LANGUAGE", "MATHEMATICS", "INTEGRATED SCIENCE", "SOCIAL STUDIES", "CHRISTIAN RELIGOUS KNOWLEGDE", "FRENCH ", "EFIK", "IBIBIO", "HEALTH & PHYSICAL EDUCATION", "BUSINESS STUDIES", "COMPUTER SCIENCE", "PHYSICS", "CHEMISTRY", "BIOLOGY", "GEOGRAPHY", "LIIT-IN-ENGLISH", "GEOGRAPHY", "AGRICULTURAL SCIENCE"})
        Me.cmbcourse2.Location = New System.Drawing.Point(36, 73)
        Me.cmbcourse2.Name = "cmbcourse2"
        Me.cmbcourse2.Size = New System.Drawing.Size(215, 21)
        Me.cmbcourse2.TabIndex = 20
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(473, 17)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(50, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "GRADE"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(133, 15)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(70, 13)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "SUBJECTS"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(353, 15)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "SCORES"
        '
        'cmbcourse1
        '
        Me.cmbcourse1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbcourse1.FormattingEnabled = True
        Me.cmbcourse1.Items.AddRange(New Object() {"", "ENGLISH LANGUAGE", "MATHEMATICS", "INTEGRATED SCIENCE", "SOCIAL STUDIES", "CHRISTIAN RELIGOUS KNOWLEGDE", "FRENCH ", "EFIK", "IBIBIO", "HEALTH & PHYSICAL EDUCATION", "BUSINESS STUDIES", "COMPUTER SCIENCE", "PHYSICS", "CHEMISTRY", "BIOLOGY", "GEOGRAPHY", "LIIT-IN-ENGLISH", "GEOGRAPHY", "AGRICULTURAL SCIENCE"})
        Me.cmbcourse1.Location = New System.Drawing.Point(36, 40)
        Me.cmbcourse1.Name = "cmbcourse1"
        Me.cmbcourse1.Size = New System.Drawing.Size(215, 21)
        Me.cmbcourse1.TabIndex = 5
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtadmissionnumber)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtstudname)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtclass)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.cmdterm)
        Me.GroupBox1.Controls.Add(Me.txtsession)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 11)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(599, 134)
        Me.GroupBox1.TabIndex = 255
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "STUDENT INFO"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.txtremark)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.txtaverage)
        Me.GroupBox3.Controls.Add(Me.txttotalscores)
        Me.GroupBox3.Location = New System.Drawing.Point(9, 465)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(407, 101)
        Me.GroupBox3.TabIndex = 256
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "GRADE DETAILS"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(27, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 13)
        Me.Label3.TabIndex = 52
        Me.Label3.Text = "REMARK"
        '
        'txtremark
        '
        Me.txtremark.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtremark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtremark.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtremark.ForeColor = System.Drawing.SystemColors.Info
        Me.txtremark.Location = New System.Drawing.Point(132, 45)
        Me.txtremark.Name = "txtremark"
        Me.txtremark.ReadOnly = True
        Me.txtremark.Size = New System.Drawing.Size(269, 25)
        Me.txtremark.TabIndex = 51
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(27, 74)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(65, 13)
        Me.Label18.TabIndex = 50
        Me.Label18.Text = "AVERAGE"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(27, 20)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(101, 13)
        Me.Label15.TabIndex = 47
        Me.Label15.Text = "TOTAL SCORES"
        '
        'txtaverage
        '
        Me.txtaverage.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtaverage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtaverage.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaverage.ForeColor = System.Drawing.SystemColors.Info
        Me.txtaverage.Location = New System.Drawing.Point(132, 71)
        Me.txtaverage.Name = "txtaverage"
        Me.txtaverage.ReadOnly = True
        Me.txtaverage.Size = New System.Drawing.Size(130, 25)
        Me.txtaverage.TabIndex = 49
        '
        'txttotalscores
        '
        Me.txttotalscores.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txttotalscores.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttotalscores.Font = New System.Drawing.Font("Segoe Script", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttotalscores.ForeColor = System.Drawing.SystemColors.Info
        Me.txttotalscores.Location = New System.Drawing.Point(132, 19)
        Me.txttotalscores.Name = "txttotalscores"
        Me.txttotalscores.ReadOnly = True
        Me.txttotalscores.Size = New System.Drawing.Size(130, 25)
        Me.txttotalscores.TabIndex = 48
        '
        'btnreset
        '
        Me.btnreset.Location = New System.Drawing.Point(665, 503)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(75, 23)
        Me.btnreset.TabIndex = 260
        Me.btnreset.Text = "&Reset"
        Me.btnreset.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Location = New System.Drawing.Point(665, 534)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 23)
        Me.btnexit.TabIndex = 259
        Me.btnexit.Text = "&Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'btncompute
        '
        Me.btncompute.Location = New System.Drawing.Point(584, 503)
        Me.btncompute.Name = "btncompute"
        Me.btncompute.Size = New System.Drawing.Size(75, 23)
        Me.btncompute.TabIndex = 258
        Me.btncompute.Text = "COMPUTE"
        Me.btncompute.UseVisualStyleBackColor = True
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(583, 534)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 23)
        Me.btnsave.TabIndex = 257
        Me.btnsave.Text = "SAVE"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'Computegrade
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOrange
        Me.ClientSize = New System.Drawing.Size(1016, 598)
        Me.Controls.Add(Me.btnreset)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btncompute)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Computegrade"
        Me.Text = "Compute Grade"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents txtadmissionnumber As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtstudname As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtclass As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtsession As System.Windows.Forms.TextBox
    Friend WithEvents cmdterm As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents result7 As System.Windows.Forms.Label
    Friend WithEvents result6 As System.Windows.Forms.Label
    Friend WithEvents result5 As System.Windows.Forms.Label
    Friend WithEvents result4 As System.Windows.Forms.Label
    Friend WithEvents result3 As System.Windows.Forms.Label
    Friend WithEvents result2 As System.Windows.Forms.Label
    Friend WithEvents result1 As System.Windows.Forms.Label
    Friend WithEvents remark7 As System.Windows.Forms.Label
    Friend WithEvents score7 As System.Windows.Forms.TextBox
    Friend WithEvents cmbcourse7 As System.Windows.Forms.ComboBox
    Friend WithEvents remark6 As System.Windows.Forms.Label
    Friend WithEvents remark5 As System.Windows.Forms.Label
    Friend WithEvents remark4 As System.Windows.Forms.Label
    Friend WithEvents remark3 As System.Windows.Forms.Label
    Friend WithEvents remark2 As System.Windows.Forms.Label
    Friend WithEvents remark1 As System.Windows.Forms.Label
    Friend WithEvents score6 As System.Windows.Forms.TextBox
    Friend WithEvents score5 As System.Windows.Forms.TextBox
    Friend WithEvents score4 As System.Windows.Forms.TextBox
    Friend WithEvents score3 As System.Windows.Forms.TextBox
    Friend WithEvents score2 As System.Windows.Forms.TextBox
    Friend WithEvents score1 As System.Windows.Forms.TextBox
    Friend WithEvents cmbcourse6 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcourse5 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcourse4 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcourse3 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcourse2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmbcourse1 As System.Windows.Forms.ComboBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtremark As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtaverage As System.Windows.Forms.TextBox
    Friend WithEvents txttotalscores As System.Windows.Forms.TextBox
    Friend WithEvents btnreset As System.Windows.Forms.Button
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents btncompute As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
End Class
