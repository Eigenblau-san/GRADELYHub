﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Studentresult
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Studentresult))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.iblscore1 = New System.Windows.Forms.Label()
        Me.iblscore2 = New System.Windows.Forms.Label()
        Me.iblscore3 = New System.Windows.Forms.Label()
        Me.iblscore4 = New System.Windows.Forms.Label()
        Me.iblscore7 = New System.Windows.Forms.Label()
        Me.iblscore6 = New System.Windows.Forms.Label()
        Me.iblscore5 = New System.Windows.Forms.Label()
        Me.iblsubject7 = New System.Windows.Forms.Label()
        Me.iblsubject6 = New System.Windows.Forms.Label()
        Me.iblsubject5 = New System.Windows.Forms.Label()
        Me.iblsubject4 = New System.Windows.Forms.Label()
        Me.iblsubject3 = New System.Windows.Forms.Label()
        Me.iblsubject2 = New System.Windows.Forms.Label()
        Me.iblsubject1 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.iblsession = New System.Windows.Forms.Label()
        Me.iblclass = New System.Windows.Forms.Label()
        Me.iblstudentname = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.iblterm = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.iblremark = New System.Windows.Forms.Label()
        Me.iblaverage = New System.Windows.Forms.Label()
        Me.ibltotalscore = New System.Windows.Forms.Label()
        Me.iblgrade7 = New System.Windows.Forms.Label()
        Me.iblgrade6 = New System.Windows.Forms.Label()
        Me.iblgrade5 = New System.Windows.Forms.Label()
        Me.iblgrade4 = New System.Windows.Forms.Label()
        Me.iblgrade3 = New System.Windows.Forms.Label()
        Me.iblgrade2 = New System.Windows.Forms.Label()
        Me.iblgrade1 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.btnprint = New System.Windows.Forms.Button()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ibladmnumber = New System.Windows.Forms.Label()
        Me.PrintForm1 = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(718, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ibladmnumber"
        '
        'iblscore1
        '
        Me.iblscore1.AutoSize = True
        Me.iblscore1.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblscore1.Location = New System.Drawing.Point(274, 237)
        Me.iblscore1.Name = "iblscore1"
        Me.iblscore1.Size = New System.Drawing.Size(215, 17)
        Me.iblscore1.TabIndex = 207
        Me.iblscore1.Text = "......................."
        '
        'iblscore2
        '
        Me.iblscore2.AutoSize = True
        Me.iblscore2.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblscore2.Location = New System.Drawing.Point(274, 268)
        Me.iblscore2.Name = "iblscore2"
        Me.iblscore2.Size = New System.Drawing.Size(215, 17)
        Me.iblscore2.TabIndex = 208
        Me.iblscore2.Text = "......................."
        '
        'iblscore3
        '
        Me.iblscore3.AutoSize = True
        Me.iblscore3.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblscore3.Location = New System.Drawing.Point(274, 300)
        Me.iblscore3.Name = "iblscore3"
        Me.iblscore3.Size = New System.Drawing.Size(215, 17)
        Me.iblscore3.TabIndex = 209
        Me.iblscore3.Text = "......................."
        '
        'iblscore4
        '
        Me.iblscore4.AutoSize = True
        Me.iblscore4.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblscore4.Location = New System.Drawing.Point(274, 330)
        Me.iblscore4.Name = "iblscore4"
        Me.iblscore4.Size = New System.Drawing.Size(215, 17)
        Me.iblscore4.TabIndex = 210
        Me.iblscore4.Text = "......................."
        '
        'iblscore7
        '
        Me.iblscore7.AutoSize = True
        Me.iblscore7.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblscore7.Location = New System.Drawing.Point(275, 424)
        Me.iblscore7.Name = "iblscore7"
        Me.iblscore7.Size = New System.Drawing.Size(215, 17)
        Me.iblscore7.TabIndex = 213
        Me.iblscore7.Text = "......................."
        '
        'iblscore6
        '
        Me.iblscore6.AutoSize = True
        Me.iblscore6.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblscore6.Location = New System.Drawing.Point(275, 392)
        Me.iblscore6.Name = "iblscore6"
        Me.iblscore6.Size = New System.Drawing.Size(215, 17)
        Me.iblscore6.TabIndex = 212
        Me.iblscore6.Text = "......................."
        '
        'iblscore5
        '
        Me.iblscore5.AutoSize = True
        Me.iblscore5.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblscore5.Location = New System.Drawing.Point(275, 361)
        Me.iblscore5.Name = "iblscore5"
        Me.iblscore5.Size = New System.Drawing.Size(215, 17)
        Me.iblscore5.TabIndex = 211
        Me.iblscore5.Text = "......................."
        '
        'iblsubject7
        '
        Me.iblsubject7.AutoSize = True
        Me.iblsubject7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblsubject7.Location = New System.Drawing.Point(13, 425)
        Me.iblsubject7.Name = "iblsubject7"
        Me.iblsubject7.Size = New System.Drawing.Size(73, 18)
        Me.iblsubject7.TabIndex = 220
        Me.iblsubject7.Text = "Subjects"
        '
        'iblsubject6
        '
        Me.iblsubject6.AutoSize = True
        Me.iblsubject6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblsubject6.Location = New System.Drawing.Point(13, 393)
        Me.iblsubject6.Name = "iblsubject6"
        Me.iblsubject6.Size = New System.Drawing.Size(73, 18)
        Me.iblsubject6.TabIndex = 219
        Me.iblsubject6.Text = "Subjects"
        '
        'iblsubject5
        '
        Me.iblsubject5.AutoSize = True
        Me.iblsubject5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblsubject5.Location = New System.Drawing.Point(13, 362)
        Me.iblsubject5.Name = "iblsubject5"
        Me.iblsubject5.Size = New System.Drawing.Size(73, 18)
        Me.iblsubject5.TabIndex = 218
        Me.iblsubject5.Text = "Subjects"
        '
        'iblsubject4
        '
        Me.iblsubject4.AutoSize = True
        Me.iblsubject4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblsubject4.Location = New System.Drawing.Point(12, 331)
        Me.iblsubject4.Name = "iblsubject4"
        Me.iblsubject4.Size = New System.Drawing.Size(73, 18)
        Me.iblsubject4.TabIndex = 217
        Me.iblsubject4.Text = "Subjects"
        '
        'iblsubject3
        '
        Me.iblsubject3.AutoSize = True
        Me.iblsubject3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblsubject3.Location = New System.Drawing.Point(12, 301)
        Me.iblsubject3.Name = "iblsubject3"
        Me.iblsubject3.Size = New System.Drawing.Size(73, 18)
        Me.iblsubject3.TabIndex = 216
        Me.iblsubject3.Text = "Subjects"
        '
        'iblsubject2
        '
        Me.iblsubject2.AutoSize = True
        Me.iblsubject2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblsubject2.Location = New System.Drawing.Point(12, 269)
        Me.iblsubject2.Name = "iblsubject2"
        Me.iblsubject2.Size = New System.Drawing.Size(73, 18)
        Me.iblsubject2.TabIndex = 215
        Me.iblsubject2.Text = "Subjects"
        '
        'iblsubject1
        '
        Me.iblsubject1.AutoSize = True
        Me.iblsubject1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblsubject1.Location = New System.Drawing.Point(12, 238)
        Me.iblsubject1.Name = "iblsubject1"
        Me.iblsubject1.Size = New System.Drawing.Size(73, 18)
        Me.iblsubject1.TabIndex = 214
        Me.iblsubject1.Text = "Subjects"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(25, 133)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(73, 20)
        Me.Label17.TabIndex = 227
        Me.Label17.Text = "Session"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(25, 101)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 20)
        Me.Label18.TabIndex = 226
        Me.Label18.Text = "Class"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(25, 70)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(124, 20)
        Me.Label19.TabIndex = 225
        Me.Label19.Text = "Student Name"
        '
        'iblsession
        '
        Me.iblsession.AutoSize = True
        Me.iblsession.Font = New System.Drawing.Font("Segoe Script", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblsession.Location = New System.Drawing.Point(188, 133)
        Me.iblsession.Name = "iblsession"
        Me.iblsession.Size = New System.Drawing.Size(78, 20)
        Me.iblsession.TabIndex = 224
        Me.iblsession.Text = "......................."
        '
        'iblclass
        '
        Me.iblclass.AutoSize = True
        Me.iblclass.Font = New System.Drawing.Font("Segoe Script", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblclass.Location = New System.Drawing.Point(188, 101)
        Me.iblclass.Name = "iblclass"
        Me.iblclass.Size = New System.Drawing.Size(78, 20)
        Me.iblclass.TabIndex = 223
        Me.iblclass.Text = "......................."
        '
        'iblstudentname
        '
        Me.iblstudentname.AutoSize = True
        Me.iblstudentname.Font = New System.Drawing.Font("Segoe Script", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblstudentname.Location = New System.Drawing.Point(188, 70)
        Me.iblstudentname.Name = "iblstudentname"
        Me.iblstudentname.Size = New System.Drawing.Size(78, 20)
        Me.iblstudentname.TabIndex = 222
        Me.iblstudentname.Text = "......................."
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(25, 165)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(49, 20)
        Me.Label23.TabIndex = 229
        Me.Label23.Text = "Term"
        '
        'iblterm
        '
        Me.iblterm.AutoSize = True
        Me.iblterm.Font = New System.Drawing.Font("Segoe Script", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblterm.Location = New System.Drawing.Point(188, 165)
        Me.iblterm.Name = "iblterm"
        Me.iblterm.Size = New System.Drawing.Size(78, 20)
        Me.iblterm.TabIndex = 228
        Me.iblterm.Text = "......................."
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label16.Location = New System.Drawing.Point(145, 536)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(67, 18)
        Me.Label16.TabIndex = 235
        Me.Label16.Text = "Remark"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label25.Location = New System.Drawing.Point(145, 504)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(68, 18)
        Me.Label25.TabIndex = 234
        Me.Label25.Text = "Average"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label26.Location = New System.Drawing.Point(145, 473)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(96, 18)
        Me.Label26.TabIndex = 233
        Me.Label26.Text = "Total Score"
        '
        'iblremark
        '
        Me.iblremark.AutoSize = True
        Me.iblremark.Font = New System.Drawing.Font("Segoe Script", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblremark.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.iblremark.Location = New System.Drawing.Point(301, 536)
        Me.iblremark.Name = "iblremark"
        Me.iblremark.Size = New System.Drawing.Size(78, 20)
        Me.iblremark.TabIndex = 232
        Me.iblremark.Text = "......................."
        '
        'iblaverage
        '
        Me.iblaverage.AutoSize = True
        Me.iblaverage.Font = New System.Drawing.Font("Segoe Script", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblaverage.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.iblaverage.Location = New System.Drawing.Point(301, 504)
        Me.iblaverage.Name = "iblaverage"
        Me.iblaverage.Size = New System.Drawing.Size(78, 20)
        Me.iblaverage.TabIndex = 231
        Me.iblaverage.Text = "......................."
        '
        'ibltotalscore
        '
        Me.ibltotalscore.AutoSize = True
        Me.ibltotalscore.Font = New System.Drawing.Font("Segoe Script", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ibltotalscore.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ibltotalscore.Location = New System.Drawing.Point(301, 473)
        Me.ibltotalscore.Name = "ibltotalscore"
        Me.ibltotalscore.Size = New System.Drawing.Size(78, 20)
        Me.ibltotalscore.TabIndex = 230
        Me.ibltotalscore.Text = "......................."
        '
        'iblgrade7
        '
        Me.iblgrade7.AutoSize = True
        Me.iblgrade7.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblgrade7.Location = New System.Drawing.Point(371, 425)
        Me.iblgrade7.Name = "iblgrade7"
        Me.iblgrade7.Size = New System.Drawing.Size(215, 17)
        Me.iblgrade7.TabIndex = 242
        Me.iblgrade7.Text = "......................."
        '
        'iblgrade6
        '
        Me.iblgrade6.AutoSize = True
        Me.iblgrade6.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblgrade6.Location = New System.Drawing.Point(371, 393)
        Me.iblgrade6.Name = "iblgrade6"
        Me.iblgrade6.Size = New System.Drawing.Size(215, 17)
        Me.iblgrade6.TabIndex = 241
        Me.iblgrade6.Text = "......................."
        '
        'iblgrade5
        '
        Me.iblgrade5.AutoSize = True
        Me.iblgrade5.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblgrade5.Location = New System.Drawing.Point(371, 362)
        Me.iblgrade5.Name = "iblgrade5"
        Me.iblgrade5.Size = New System.Drawing.Size(215, 17)
        Me.iblgrade5.TabIndex = 240
        Me.iblgrade5.Text = "......................."
        '
        'iblgrade4
        '
        Me.iblgrade4.AutoSize = True
        Me.iblgrade4.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblgrade4.Location = New System.Drawing.Point(370, 331)
        Me.iblgrade4.Name = "iblgrade4"
        Me.iblgrade4.Size = New System.Drawing.Size(215, 17)
        Me.iblgrade4.TabIndex = 239
        Me.iblgrade4.Text = "......................."
        '
        'iblgrade3
        '
        Me.iblgrade3.AutoSize = True
        Me.iblgrade3.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblgrade3.Location = New System.Drawing.Point(370, 301)
        Me.iblgrade3.Name = "iblgrade3"
        Me.iblgrade3.Size = New System.Drawing.Size(215, 17)
        Me.iblgrade3.TabIndex = 238
        Me.iblgrade3.Text = "......................."
        '
        'iblgrade2
        '
        Me.iblgrade2.AutoSize = True
        Me.iblgrade2.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblgrade2.Location = New System.Drawing.Point(370, 269)
        Me.iblgrade2.Name = "iblgrade2"
        Me.iblgrade2.Size = New System.Drawing.Size(215, 17)
        Me.iblgrade2.TabIndex = 237
        Me.iblgrade2.Text = "......................."
        '
        'iblgrade1
        '
        Me.iblgrade1.AutoSize = True
        Me.iblgrade1.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.iblgrade1.Location = New System.Drawing.Point(370, 238)
        Me.iblgrade1.Name = "iblgrade1"
        Me.iblgrade1.Size = New System.Drawing.Size(215, 17)
        Me.iblgrade1.TabIndex = 236
        Me.iblgrade1.Text = "......................."
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Crimson
        Me.Label37.Location = New System.Drawing.Point(270, 208)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(84, 18)
        Me.Label37.TabIndex = 243
        Me.Label37.Text = "Score (%)"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Crimson
        Me.Label38.Location = New System.Drawing.Point(375, 208)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(54, 18)
        Me.Label38.TabIndex = 244
        Me.Label38.Text = "Grade"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Computerized_grading__system.My.Resources.Resources.users3
        Me.PictureBox1.Location = New System.Drawing.Point(479, 40)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(131, 133)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 245
        Me.PictureBox1.TabStop = False
        '
        'btncancel
        '
        Me.btncancel.BackColor = System.Drawing.Color.White
        Me.btncancel.Image = CType(resources.GetObject("btncancel.Image"), System.Drawing.Image)
        Me.btncancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btncancel.Location = New System.Drawing.Point(282, 573)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(82, 28)
        Me.btncancel.TabIndex = 247
        Me.btncancel.Text = "   &Close"
        Me.btncancel.UseVisualStyleBackColor = False
        '
        'btnprint
        '
        Me.btnprint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnprint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnprint.Location = New System.Drawing.Point(198, 573)
        Me.btnprint.Name = "btnprint"
        Me.btnprint.Size = New System.Drawing.Size(75, 28)
        Me.btnprint.TabIndex = 246
        Me.btnprint.Text = "Print"
        Me.btnprint.UseVisualStyleBackColor = True
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(234, 3)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(207, 23)
        Me.Label39.TabIndex = 248
        Me.Label39.Text = "Student E-Report Card"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(25, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(158, 20)
        Me.Label2.TabIndex = 250
        Me.Label2.Text = "Admission Number"
        '
        'ibladmnumber
        '
        Me.ibladmnumber.AutoSize = True
        Me.ibladmnumber.Font = New System.Drawing.Font("Segoe Script", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ibladmnumber.Location = New System.Drawing.Point(188, 40)
        Me.ibladmnumber.Name = "ibladmnumber"
        Me.ibladmnumber.Size = New System.Drawing.Size(78, 20)
        Me.ibladmnumber.TabIndex = 249
        Me.ibladmnumber.Text = "......................."
        '
        'PrintForm1
        '
        Me.PrintForm1.DocumentName = "document"
        Me.PrintForm1.Form = Me
        Me.PrintForm1.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.PrintForm1.PrinterSettings = CType(resources.GetObject("PrintForm1.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.PrintForm1.PrintFileName = Nothing
        '
        'Studentresult
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(618, 608)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ibladmnumber)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnprint)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.iblgrade7)
        Me.Controls.Add(Me.iblgrade6)
        Me.Controls.Add(Me.iblgrade5)
        Me.Controls.Add(Me.iblgrade4)
        Me.Controls.Add(Me.iblgrade3)
        Me.Controls.Add(Me.iblgrade2)
        Me.Controls.Add(Me.iblgrade1)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.iblremark)
        Me.Controls.Add(Me.iblaverage)
        Me.Controls.Add(Me.ibltotalscore)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.iblterm)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.iblsession)
        Me.Controls.Add(Me.iblclass)
        Me.Controls.Add(Me.iblstudentname)
        Me.Controls.Add(Me.iblsubject7)
        Me.Controls.Add(Me.iblsubject6)
        Me.Controls.Add(Me.iblsubject5)
        Me.Controls.Add(Me.iblsubject4)
        Me.Controls.Add(Me.iblsubject3)
        Me.Controls.Add(Me.iblsubject2)
        Me.Controls.Add(Me.iblsubject1)
        Me.Controls.Add(Me.iblscore7)
        Me.Controls.Add(Me.iblscore6)
        Me.Controls.Add(Me.iblscore5)
        Me.Controls.Add(Me.iblscore4)
        Me.Controls.Add(Me.iblscore3)
        Me.Controls.Add(Me.iblscore2)
        Me.Controls.Add(Me.iblscore1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Studentresult"
        Me.Text = "Studentresult"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents iblscore1 As System.Windows.Forms.Label
    Friend WithEvents iblscore2 As System.Windows.Forms.Label
    Friend WithEvents iblscore3 As System.Windows.Forms.Label
    Friend WithEvents iblscore4 As System.Windows.Forms.Label
    Friend WithEvents iblscore7 As System.Windows.Forms.Label
    Friend WithEvents iblscore6 As System.Windows.Forms.Label
    Friend WithEvents iblscore5 As System.Windows.Forms.Label
    Friend WithEvents iblsubject7 As System.Windows.Forms.Label
    Friend WithEvents iblsubject6 As System.Windows.Forms.Label
    Friend WithEvents iblsubject5 As System.Windows.Forms.Label
    Friend WithEvents iblsubject4 As System.Windows.Forms.Label
    Friend WithEvents iblsubject3 As System.Windows.Forms.Label
    Friend WithEvents iblsubject2 As System.Windows.Forms.Label
    Friend WithEvents iblsubject1 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents iblsession As System.Windows.Forms.Label
    Friend WithEvents iblclass As System.Windows.Forms.Label
    Friend WithEvents iblstudentname As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents iblterm As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents iblremark As System.Windows.Forms.Label
    Friend WithEvents iblaverage As System.Windows.Forms.Label
    Friend WithEvents ibltotalscore As System.Windows.Forms.Label
    Friend WithEvents iblgrade7 As System.Windows.Forms.Label
    Friend WithEvents iblgrade6 As System.Windows.Forms.Label
    Friend WithEvents iblgrade5 As System.Windows.Forms.Label
    Friend WithEvents iblgrade4 As System.Windows.Forms.Label
    Friend WithEvents iblgrade3 As System.Windows.Forms.Label
    Friend WithEvents iblgrade2 As System.Windows.Forms.Label
    Friend WithEvents iblgrade1 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnprint As System.Windows.Forms.Button
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ibladmnumber As System.Windows.Forms.Label
    Friend WithEvents PrintForm1 As Microsoft.VisualBasic.PowerPacks.Printing.PrintForm
End Class
