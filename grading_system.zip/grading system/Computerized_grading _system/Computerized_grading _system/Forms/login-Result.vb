﻿Imports System.Data.OleDb

Public Class loginResult

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Me.Close()
    End Sub
    Private Sub login()
        Try
            If txtadmnumber.Text = "" And txtsession.Text = "" And cmdterm.Text = "" Then
                MsgBox("Please enter Admission Number and Session And Term")
                txtadmnumber.Focus()
            Else
                sqL = "SELECT * FROM grade WHERE admnumber = '" & txtadmnumber.Text & "' AND session1 ='" & txtsession.Text & "'And term = '" & cmdterm.Text & "'"
                ConnDB()
                cmd = New OleDbCommand(sqL, conn)
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
                If dr.Read = True Then
                    Studentresult.Show()
                    Me.Hide()
                Else
                    MsgBox("Data Supplied is Not Correct", MsgBoxStyle.Information, "Student Result")
                End If
                conn.Close()
            End If
        Catch ex As Exception
            MsgBox("" & ex.Message)
        End Try
    End Sub
    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        login()
    End Sub
    Private Sub loginResult_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Left = (Screen.PrimaryScreen.WorkingArea.Width - Me.Width) / 2
        Me.Top = (Screen.PrimaryScreen.WorkingArea.Height - Me.Height) / 2
    End Sub
End Class